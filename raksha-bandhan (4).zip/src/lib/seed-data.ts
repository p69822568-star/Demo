/**
 * Realistic demo content used to seed the database on first boot,
 * so the site feels alive immediately.
 */
import { PERSONAL_PHOTOS } from "./constants";

export const SEED_QUOTES: { text: string; author: string | null }[] = [
  { text: "Sisters are the heart of every family.", author: "Akash Bhai" },
  { text: "No matter how far we go, our bond never fades.", author: null },
  { text: "Rakhi is not a thread, it is a promise.", author: null },
  { text: "My sisters are my biggest blessing.", author: "Banti Bhai" },
  { text: "A brother's first best friend is always his sister.", author: null },
  { text: "Love tied in a single sacred thread lasts a lifetime.", author: null },
  { text: "Behind every strong brother stands a stronger sister.", author: null },
  { text: "Distance measures miles, not the love between siblings.", author: null },
  { text: "You protected my dreams before I even had them.", author: null },
  { text: "Childhood memories with you are my safest treasure.", author: null },
  { text: "A sister's scolding is just love spoken loudly.", author: null },
  { text: "The thread fades, the promise never does.", author: null },
];

export const SEED_TIMELINE = [
  { year: "The Beginning", title: "Childhood Days", description: "Tiny hands, shared toys, endless mischief and the loudest laughs in the house.", icon: "🍼" },
  { year: "Growing Up", title: "School Memories", description: "Same school bags, stolen tiffins, and you covering for me in every parent-teacher meeting.", icon: "🎒" },
  { year: "Always", title: "Funny Moments", description: "The pranks, the inside jokes, the dance moves nobody else will ever understand.", icon: "😂" },
  { year: "Every Season", title: "Family Functions", description: "Coordinating outfits, late-night giggles, and you fixing everything behind the scenes.", icon: "🎉" },
  { year: "Year After Year", title: "Festivals Together", description: "Diwali diyas, Holi colours, and Rakhi mornings that felt like pure magic.", icon: "🪔" },
  { year: "Sacred Thread", title: "Raksha Bandhan Memories", description: "Every Rakhi you tied carried a lifetime of love, protection and silent promises.", icon: "🧵" },
  { year: "Right Now", title: "Today & Always", description: "Different cities, same bond. A single call and the whole world feels like home.", icon: "💞" },
  { year: "Forever", title: "Future Dreams", description: "Growing old side by side, making new memories, and never letting go.", icon: "✨" },
];

export const SEED_PHOTOS = [
  { title: "Forever Family", caption: "The people who make every festival brighter.", src: PERSONAL_PHOTOS[0], category: "Family" },
  { title: "Golden Moments", caption: "A frame full of laughter and love.", src: PERSONAL_PHOTOS[1], category: "Memories" },
  { title: "Together Always", caption: "Some bonds need no words.", src: PERSONAL_PHOTOS[2], category: "Memories" },
  { title: "Pure Joy", caption: "The smile only family can bring.", src: PERSONAL_PHOTOS[3], category: "Festivals" },
];

export const SEED_WISHES = [
  { name: "Lucky Di", message: "My little brothers grew up too fast — but they'll always be my babies. Happy Raksha Bandhan! ❤️", color: "rose" },
  { name: "Vicky Di", message: "You two are the reason Rakhi feels so special. Proud of the men you've become. 💛", color: "amber" },
  { name: "Sapna", message: "No matter where life takes us, this thread keeps us close forever. 🧡", color: "violet" },
  { name: "Neha", message: "From stealing sweets to sharing secrets — every memory with you is gold. 🌹", color: "rose" },
  { name: "Kalpan", message: "Thank you for being the protective, loving brothers every sister dreams of. ✨", color: "emerald" },
];

export const WISH_TREE_BLESSINGS = [
  "May your smile never fade.",
  "You are loved more than words can hold.",
  "May every wish of yours come true.",
  "Your kindness returns to you a hundredfold.",
  "Stay wild, stay wonderful.",
  "May happiness find you in every season.",
  "You are the light of this family.",
  "May your dreams outgrow your fears.",
  "Forever protected, forever cherished.",
  "May laughter always echo in your home.",
  "Your bond is stronger than distance.",
  "May success chase you everywhere.",
  "You are someone's answered prayer.",
  "May your heart stay soft and your spirit fierce.",
  "Peace, prosperity and endless love.",
  "May your days be golden and your nights restful.",
  "You make the world a softer place.",
  "May every tear turn into a triumph.",
  "Your presence is a blessing to many.",
  "May courage walk beside you always.",
  "Stay grounded, keep soaring.",
  "May your cup of joy never run dry.",
  "You are braver than you believe.",
  "May love be your constant companion.",
  "Your story is still being written — beautifully.",
  "May good health be your lifelong friend.",
  "You are appreciated more than you know.",
  "May miracles quietly find you.",
  "Stay curious, stay kind.",
  "May your family tree stay rooted in love.",
  "You are a gift to everyone who knows you.",
  "May abundance flow into your life.",
  "Keep shining, the world needs your light.",
  "May your confidence grow with every sunrise.",
  "You deserve every good thing coming.",
  "May your home always feel like a hug.",
  "Stay blessed, stay blissful.",
  "May new adventures find you ready.",
  "Your patience will be rewarded.",
  "May gentle people always cross your path.",
  "You are stronger than any storm.",
  "May your heart forgive quickly and love deeply.",
  "Keep dreaming, keep becoming.",
  "May your hard work blossom beautifully.",
  "You are exactly where you need to be.",
  "May music always live in your soul.",
  "Stay surrounded by those who celebrate you.",
  "May your future be brighter than your past.",
  "You are loved, today and always.",
];
