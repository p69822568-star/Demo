/**
 * Lightweight WebAudio sound effects (no audio files needed).
 * All functions no-op gracefully if audio isn't available.
 */

let ctx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(freq: number, dur: number, type: OscillatorType = "sine", gain = 0.12, startAt = 0) {
  const c = getCtx();
  if (!c) return;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  osc.connect(g);
  g.connect(c.destination);
  const t = c.currentTime + startAt;
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(gain, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.start(t);
  osc.stop(t + dur);
}

export const sfx = {
  click: () => tone(520, 0.08, "triangle", 0.08),
  pop: () => tone(740, 0.1, "sine", 0.1),
  ding: () => { tone(880, 0.12, "sine", 0.12); tone(1320, 0.18, "sine", 0.08, 0.06); },
  win: () => { [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.2, "triangle", 0.12, i * 0.1)); },
  sparkle: () => { tone(1318, 0.06, "sine", 0.06); tone(1760, 0.08, "sine", 0.05, 0.05); },
  bell: () => { tone(660, 0.5, "sine", 0.1); tone(990, 0.6, "sine", 0.06, 0.02); },
  whoosh: () => tone(220, 0.4, "sawtooth", 0.05),
  sad: () => { tone(330, 0.2, "sine", 0.08); tone(247, 0.3, "sine", 0.08, 0.15); },
};
