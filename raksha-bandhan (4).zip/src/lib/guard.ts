import { NextResponse } from "next/server";
import { getSession } from "./session";

/** Returns the session user, or a 401 response. */
export async function requireUser() {
  const session = await getSession();
  if (!session) {
    return {
      user: null as null,
      response: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }
  return { user: session, response: null };
}
