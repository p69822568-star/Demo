/**
 * Centralised content & asset configuration.
 * Owner: Akash Bhai & Banti Bhai
 * Dedicated to: Lucky Di ❤️ Vicky Di ❤️ Sapna ❤️ Neha ❤️ Kalpan
 */

export const SITE = {
  title: "Raksha Bandhan — A Bond Beyond Words",
  owners: "Akash Bhai & Banti Bhai",
  sisters: [
    "Lucky Di",
    "Vicky Di",
    "Sapna",
    "Neha",
    "Kalpan",
  ],
} as const;

/** Personal photos provided by the owner (hosted on ImgBB). */
export const PERSONAL_PHOTOS = [
  "https://i.ibb.co/93YkgKQ5/IMG-20260729-WA0000.jpg",
  "https://i.ibb.co/nNNjRjQB/IMG-20260729-WA0003.jpg",
  "https://i.ibb.co/TM1NBP6T/IMG-20260729-WA0001.jpg",
  "https://i.ibb.co/fYK0hGQp/IMG-20260729-WA0002.jpg",
] as const;

/** Background music provided by the owner (emotional instrumental). */
export const SONG_URL = "https://files.catbox.moe/n4xlp8.mp3";

/** Rakhi ceremony hand image (hosted on ImgBB). */
export const RAKHI_HAND_IMAGE = "https://i.ibb.co/mpFmDWY/rakhi-2630652-1280.jpg";

/** Raksha Bandhan dates (Hindu lunar calendar, Shravana Purnima). */
const RAKHI_DATES = [
  new Date("2026-08-28T00:00:00+05:30"),
  new Date("2027-08-17T00:00:00+05:30"),
  new Date("2028-08-05T00:00:00+05:30"),
  new Date("2029-08-24T00:00:00+05:30"),
  new Date("2030-08-14T00:00:00+05:30"),
];

export function nextRakshaBandhan(now: Date = new Date()): Date {
  return RAKHI_DATES.find((d) => d.getTime() > now.getTime()) ?? RAKHI_DATES[RAKHI_DATES.length - 1];
}

/**
 * Gift Corner unlock moment: 12:00 noon IST on Raksha Bandhan day.
 * Returns an absolute timestamp (ms). Gifts stay locked before this.
 */
export function giftUnlockTime(now: Date = new Date()): number {
  return nextRakshaBandhan(now).getTime() + 12 * 3600 * 1000; // noon IST
}

/** Personal gifts for each sister (edit freely). */
export const GIFTS = [
  {
    sister: "Lucky Di",
    gift: "A Beautiful Kurti",
    emoji: "👗",
    note: "Kyunki tum hamesha sabse sundar — andar se bahar tak. 🌸",
    color: "from-rose-500/30 to-pink-700/20",
  },
  {
    sister: "Vicky Di",
    gift: "Golden Jhumka Box",
    emoji: "💍",
    note: "Thodi si chamak, unke pyaar jaisi. Hamesha roshan raho. ✨",
    color: "from-amber-500/30 to-orange-700/20",
  },
  {
    sister: "Sapna",
    gift: "Special Coffee Cup",
    emoji: "☕",
    note: "Har subah ki chai-coffee, tumhari hansi ke saath. ☀️",
    color: "from-amber-600/30 to-yellow-800/20",
  },
  {
    sister: "Neha",
    gift: "Smart Writing Tab",
    emoji: "📲",
    note: "Tumhare sapno aur ideas ke liye — likho, bano, chamko. 🚀",
    color: "from-violet-500/30 to-purple-700/20",
  },
] as const;
