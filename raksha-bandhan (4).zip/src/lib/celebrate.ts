import confetti from "canvas-confetti";

const GOLD = ["#ffe9a8", "#f5c542", "#d4a017", "#fff8ee", "#f3b8c8", "#a855f7"];

/** Burst of golden confetti from the centre. */
export function goldConfetti(originY = 0.6) {
  confetti({
    particleCount: 90,
    spread: 80,
    startVelocity: 45,
    origin: { x: 0.5, y: originY },
    colors: GOLD,
    scalar: 1.1,
    ticks: 220,
  });
}

/** Side-cannon celebration (correct quiz answer, reveal, etc). */
export function celebrate() {
  confetti({ particleCount: 60, spread: 70, origin: { x: 0.2, y: 0.7 }, colors: GOLD });
  confetti({ particleCount: 60, spread: 70, origin: { x: 0.8, y: 0.7 }, colors: GOLD });
}

/** Big celebratory burst for ceremony / wheel / surprises. */
export function bigCelebrate() {
  const end = Date.now() + 1100;
  (function frame() {
    confetti({ particleCount: 6, angle: 60, spread: 60, origin: { x: 0 }, colors: GOLD });
    confetti({ particleCount: 6, angle: 120, spread: 60, origin: { x: 1 }, colors: GOLD });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();
}

/** Firework-style finale for the closing section. */
export function fireworksFinale() {
  const duration = 2600;
  const animationEnd = Date.now() + duration;
  const defaults = { startVelocity: 30, spread: 360, ticks: 90, zIndex: 9999, colors: GOLD };

  const interval = window.setInterval(() => {
    const msLeft = animationEnd - Date.now();
    if (msLeft <= 0) return clearInterval(interval);
    const particleCount = 50 * (msLeft / duration);
    confetti({
      ...defaults,
      particleCount,
      origin: { x: randomInRange(0.1, 0.9), y: Math.random() - 0.2 },
    });
  }, 260);
}

/** Hearts burst from a specific point (used by memory wall etc). */
export function heartBurst(x = 0.5, y = 0.5) {
  confetti({
    particleCount: 40,
    spread: 60,
    startVelocity: 28,
    origin: { x, y },
    shapes: ["circle"],
    colors: ["#e8a0b8", "#f3b8c8", "#ff5d8f", "#fff"],
    scalar: 1.3,
  });
}

function randomInRange(min: number, max: number) {
  return Math.random() * (max - min) + min;
}
