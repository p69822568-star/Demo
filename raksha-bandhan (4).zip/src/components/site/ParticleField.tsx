"use client";

import { useEffect, useRef } from "react";

type P = {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  a: number;
  tw: number; // twinkle speed
  hue: string;
  kind: "dust" | "star" | "firefly" | "petal";
  rot: number;
  vr: number;
};

/**
 * Full-screen animated particle canvas.
 * Renders golden dust, twinkling stars, drifting fireflies & petals.
 */
export default function ParticleField() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = (canvas.width = window.innerWidth);
    let h = (canvas.height = window.innerHeight);
    let raf = 0;

    const isMobile = window.innerWidth < 768;
    const count = isMobile ? 70 : 150;
    const colors = ["#ffe9a8", "#f5c542", "#fff8ee", "#a855f7", "#f3b8c8"];

    const rand = (a: number, b: number) => a + Math.random() * (b - a);

    const particles: P[] = Array.from({ length: count }, () => {
      const roll = Math.random();
      const kind: P["kind"] =
        roll < 0.4 ? "dust" : roll < 0.7 ? "star" : roll < 0.9 ? "firefly" : "petal";
      return {
        x: Math.random() * w,
        y: Math.random() * h,
        r: kind === "petal" ? rand(4, 8) : kind === "star" ? rand(0.6, 1.6) : rand(0.8, 2.6),
        vx: kind === "petal" ? rand(-0.4, 0.4) : rand(-0.2, 0.2),
        vy: kind === "dust" ? rand(-0.5, -0.15) : kind === "petal" ? rand(0.4, 1) : rand(-0.15, 0.15),
        a: rand(0.2, 0.9),
        tw: rand(0.005, 0.02),
        hue: colors[(Math.random() * colors.length) | 0],
        kind,
        rot: Math.random() * Math.PI,
        vr: rand(-0.02, 0.02),
      };
    });

    const drawPetal = (p: P) => {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.globalAlpha = p.a * 0.7;
      ctx.fillStyle = p.hue;
      ctx.beginPath();
      ctx.ellipse(0, 0, p.r, p.r * 0.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    const tick = () => {
      ctx.clearRect(0, 0, w, h);
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        p.rot += p.vr;
        p.a += Math.sin(performance.now() * p.tw) * 0.01;

        // recycle
        if (p.kind === "dust" && p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
        if (p.kind === "petal" && p.y > h + 10) { p.y = -10; p.x = Math.random() * w; }
        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;

        const alpha = Math.max(0.05, Math.min(1, p.a));

        if (p.kind === "petal") {
          drawPetal(p);
          continue;
        }

        ctx.beginPath();
        ctx.globalAlpha = alpha;
        if (p.kind === "star") {
          ctx.fillStyle = p.hue;
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fill();
        } else {
          // glow
          const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4);
          g.addColorStop(0, p.hue);
          g.addColorStop(1, "transparent");
          ctx.fillStyle = g;
          ctx.arc(p.x, p.y, p.r * 4, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = alpha;
          ctx.fillStyle = "#fff";
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 0.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(tick);
    };

    tick();

    const onResize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", onResize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      className="pointer-events-none fixed inset-0 z-[1] h-full w-full"
      aria-hidden
    />
  );
}
