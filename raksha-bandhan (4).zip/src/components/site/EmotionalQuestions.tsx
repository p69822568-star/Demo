"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, ArrowRight } from "lucide-react";
import { SectionHeading, SectionWrap } from "./Primitives";

const PROMPTS = [
  "Which memory with your brother makes you smile the most?",
  "If you could relive one Raksha Bandhan, which one would it be?",
  "What is one thing you never said but always wanted to?",
  "What promise should siblings never break?",
  "What makes this relationship special?",
];

export default function EmotionalQuestions() {
  const [i, setI] = useState(0);
  const [answer, setAnswer] = useState("");
  const [revealed, setRevealed] = useState(false);

  const next = () => {
    if (!revealed) {
      setRevealed(true);
      return;
    }
    setAnswer("");
    setRevealed(false);
    setI((p) => (p + 1) % PROMPTS.length);
  };

  return (
    <SectionWrap id="reflect">
      <SectionHeading
        eyebrow="a quiet moment"
        title={<>Questions for the <span className="gradient-gold-text">Heart</span></>}
        subtitle="One gentle question at a time. Say it in your heart — or write it down."
      />

      <div className="mx-auto max-w-2xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            className="glass-strong rounded-3xl p-7 md:p-10"
          >
            <div className="mb-2 flex items-center gap-2 text-rose-300">
              <Heart className="h-5 w-5 fill-rose-300 anim-heartbeat" />
              <span className="text-xs uppercase tracking-widest">Question {i + 1} of {PROMPTS.length}</span>
            </div>

            <AnimatePresence mode="wait">
              {!revealed ? (
                <motion.div key="ask" exit={{ opacity: 0 }}>
                  <h3 className="font-display text-2xl text-amber-50 md:text-3xl">{PROMPTS[i]}</h3>
                  <textarea
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value)}
                    rows={3}
                    placeholder="Let your heart speak… (optional)"
                    className="mt-5 w-full resize-none rounded-2xl border border-white/10 bg-black/30 p-4 text-amber-50 placeholder:text-white/30 focus:border-amber-300/50 focus:outline-none"
                  />
                  <button onClick={next} className="btn-gold mt-5 w-full sm:w-auto">
                    Reveal <ArrowRight className="h-4 w-4" />
                  </button>
                </motion.div>
              ) : (
                <motion.div
                  key="reveal"
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-6 text-center"
                >
                  <motion.p
                    className="font-display text-3xl gradient-gold-text md:text-4xl"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    You are loved forever ❤️
                  </motion.p>
                  <button onClick={next} className="btn-ghost mt-7">
                    {i === PROMPTS.length - 1 ? "Start over" : "Next question"} <ArrowRight className="h-4 w-4" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </AnimatePresence>
      </div>
    </SectionWrap>
  );
}
