"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { fireworksFinale } from "@/lib/celebrate";
import { SectionWrap, Reveal } from "./Primitives";

export default function FinalSurprise() {
  const ref = useRef<HTMLDivElement>(null);
  const [lit, setLit] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && entry.intersectionRatio > 0.4) {
          setLit(true);
          fireworksFinale();
        }
      },
      { threshold: 0.4 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <SectionWrap id="finale" className="pb-32">
      <div ref={ref} className="relative flex flex-col items-center text-center">
        {/* Large animated Rakhi */}
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={lit ? { scale: 1, opacity: 1 } : {}}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative mb-10 h-44 w-44"
        >
          <div className="absolute inset-0 anim-spin-slow rounded-full border-2 border-dashed border-amber-300/50" />
          <div className="absolute inset-5 anim-spin-rev rounded-full border border-purple-400/40" />
          {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
            <span
              key={i}
              className="absolute left-1/2 top-1/2 h-3 w-3 rounded-full bg-amber-300"
              style={{ transform: `rotate(${i * 45}deg) translateY(-88px)`, boxShadow: "0 0 14px #f5c542" }}
            />
          ))}
          <div className="absolute inset-12 rakhi-disc anim-pulse-glow" />
          <div className="absolute inset-[44%] rounded-full bg-amber-100 shadow-[0_0_28px_#ffe9a8]" />
        </motion.div>

        {/* floating hearts */}
        {lit &&
          Array.from({ length: 12 }).map((_, i) => (
            <motion.span
              key={i}
              className="pointer-events-none absolute text-rose-300"
              style={{ left: `${5 + i * 8}%`, bottom: 0 }}
              initial={{ opacity: 0, y: 0 }}
              animate={{ opacity: [0, 1, 0], y: [-10, -260] }}
              transition={{ duration: 5 + (i % 4), repeat: Infinity, delay: i * 0.4 }}
            >
              ❤️
            </motion.span>
          ))}

        <Reveal>
          <p className="font-script text-4xl text-rose-200 md:text-5xl">My Dear Sisters,</p>
          <p className="font-display mt-2 text-2xl text-glow-gold md:text-3xl">
            Lucky Di, Vicky Di, Sapna, Neha &amp; Kalpan
          </p>
        </Reveal>

        <Reveal delay={0.15}>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-amber-50/90">
            Thank you for filling my life with love, laughter, protection, guidance and
            unforgettable memories.
          </p>
        </Reveal>
        <Reveal delay={0.25}>
          <p className="mx-auto mt-4 max-w-xl text-lg text-amber-100/80">
            No distance, no time, no challenge can ever break our bond.
          </p>
        </Reveal>

        <Reveal delay={0.35}>
          <p className="font-display mt-8 text-4xl gradient-gold-text md:text-5xl">
            Happy Raksha Bandhan ❤️
          </p>
        </Reveal>

        <Reveal delay={0.45}>
          <div className="mt-8">
            <p className="text-sm text-amber-200/70">Forever your little brothers,</p>
            <p className="font-script text-4xl text-glow-gold">Akash Bhai &amp; Banti Bhai</p>
          </div>
        </Reveal>
      </div>
    </SectionWrap>
  );
}
