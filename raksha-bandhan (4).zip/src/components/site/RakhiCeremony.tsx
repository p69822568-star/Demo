"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SectionHeading, SectionWrap } from "./Primitives";
import { sfx } from "@/lib/sfx";
import { bigCelebrate } from "@/lib/celebrate";
import { RAKHI_HAND_IMAGE } from "@/lib/constants";

type Phase = "idle" | "tying" | "done";

export default function RakhiCeremony() {
  const [phase, setPhase] = useState<Phase>("idle");

  const tie = () => {
    if (phase !== "idle") return;
    sfx.bell();
    setPhase("tying");
    setTimeout(() => {
      sfx.win();
      bigCelebrate();
      setPhase("done");
    }, 2600);
  };

  return (
    <SectionWrap id="ceremony">
      <SectionHeading
        eyebrow="a sacred moment"
        title={<>Tie the <span className="gradient-gold-text">Rakhi</span></>}
        subtitle="Didi, rakhi iske haath pe baandho — ek tap mein, sapnon ka laal dhaga kasi jayega."
      />

      <div className="relative mx-auto flex max-w-2xl flex-col items-center rounded-3xl glass-strong p-8 text-center md:p-12">
        {/* Hand / rakhi stage */}
        <div className="relative h-64 w-64 sm:h-72 sm:w-72">
          {/* warm glow */}
          <div className="pointer-events-none absolute inset-0 rounded-full bg-[radial-gradient(circle,rgba(245,197,66,0.3),transparent_70%)] blur-2xl" />

          {/* rotating thread rings while tying */}
          <AnimatePresence>
            {phase !== "idle" &&
              [0, 1].map((r) => (
                <motion.div
                  key={r}
                  className="absolute inset-0 rounded-full border-2 border-dashed border-rose-300/70"
                  initial={{ scale: 0.9, opacity: 0, rotate: 0 }}
                  animate={{ scale: 1 + r * 0.09, opacity: [0, 1, 0.5], rotate: 360 }}
                  transition={{ duration: 2.4, repeat: Infinity, ease: "linear", delay: r * 0.2 }}
                />
              ))}
          </AnimatePresence>

          {/* the hand image */}
          <motion.div
            animate={phase === "tying" ? { scale: [1, 1.04, 1] } : { scale: [1, 1.02, 1] }}
            transition={{ duration: 2.2, repeat: Infinity }}
            className="frame-gold absolute inset-2 overflow-hidden rounded-full"
          >
            <img
              src={RAKHI_HAND_IMAGE}
              alt="Rakhi being tied on the wrist"
              className="h-full w-full object-cover"
            />
          </motion.div>

          {/* tilak */}
          <AnimatePresence>
            {phase !== "idle" && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.6, type: "spring" }}
                className="absolute left-[60%] top-[26%] text-2xl"
                style={{ filter: "drop-shadow(0 0 6px rgba(225,29,72,0.8))" }}
              >
                🔴
              </motion.span>
            )}
          </AnimatePresence>

          {/* falling petals */}
          {phase === "tying" &&
            Array.from({ length: 10 }).map((_, i) => (
              <motion.span
                key={i}
                className="absolute text-rose-300"
                initial={{ top: -10, left: `${10 + i * 9}%`, opacity: 0, rotate: 0 }}
                animate={{ top: 300, opacity: [0, 1, 0], rotate: 360 }}
                transition={{ duration: 2.2 + (i % 4) * 0.25, repeat: Infinity, delay: i * 0.12 }}
              >
                🌸
              </motion.span>
            ))}
        </div>

        {/* diya */}
        <div className="diya mt-3 scale-90">
          <div className="flame" />
          <div className="bowl" />
        </div>

        <AnimatePresence mode="wait">
          {phase === "done" ? (
            <motion.div key="done" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="mt-6 space-y-2">
              <p className="font-script text-4xl gradient-gold-text">Your bond is forever.</p>
              <p className="text-amber-100/70">Rakhi baandh di, tilak lag gaya, vaada pakka ho gaya. ❤️</p>
              <button onClick={() => setPhase("idle")} className="btn-ghost mt-2">Tie again</button>
            </motion.div>
          ) : (
            <motion.button key="tie" onClick={tie} className="btn-gold mt-6 text-base">
              {phase === "tying" ? "🧵 Sister is tying the Rakhi…" : "🪔 Tie Rakhi"}
            </motion.button>
          )}
        </AnimatePresence>
      </div>
    </SectionWrap>
  );
}
