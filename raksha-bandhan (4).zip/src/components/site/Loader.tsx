"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Loader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let p = 0;
    const id = setInterval(() => {
      p += Math.random() * 9 + 4;
      if (p >= 100) {
        p = 100;
        clearInterval(id);
        setProgress(100);
        setTimeout(() => {
          setDone(true);
          // nudge the music player to start now that the user has "entered"
          window.dispatchEvent(new Event("rakhi:enter"));
          setTimeout(onComplete, 900);
        }, 500);
      } else {
        setProgress(p);
      }
    }, 220);
    return () => clearInterval(id);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-[#04020a]"
          exit={{ opacity: 0, scale: 1.08, filter: "blur(8px)" }}
          transition={{ duration: 0.9, ease: "easeInOut" }}
        >
          {/* glow backdrop */}
          <div className="pointer-events-none absolute h-[60vmin] w-[60vmin] rounded-full bg-[radial-gradient(circle,rgba(245,197,66,0.25),transparent_60%)] blur-2xl" />

          {/* Animated Rakhi */}
          <div className="relative mb-12 h-44 w-44">
            {/* rotating thread ring */}
            <div className="absolute inset-0 anim-spin-slow rounded-full border-2 border-dashed border-amber-300/50" />
            <div className="absolute inset-3 anim-spin-rev rounded-full border border-purple-400/40" />
            {/* orbiting beads */}
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <span
                key={i}
                className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-amber-300 anim-spin-slow"
                style={{
                  transform: `rotate(${i * 60}deg) translateY(-80px)`,
                  boxShadow: "0 0 12px #f5c542",
                  animationDuration: `${10 + i}s`,
                }}
              />
            ))}
            {/* central disc */}
            <div className="absolute inset-10 rakhi-disc anim-pulse-glow" />
            <div className="absolute inset-[46%] rounded-full bg-amber-100 shadow-[0_0_20px_#ffe9a8]" />
          </div>

          <p className="font-display text-2xl text-glow-gold md:text-3xl">Loading Memories…</p>
          <p className="font-script mt-1 text-2xl text-rose-200">tying the sacred thread</p>

          {/* progress */}
          <div className="mt-8 h-1.5 w-64 overflow-hidden rounded-full bg-white/10">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-amber-300 via-yellow-200 to-purple-400"
              animate={{ width: `${progress}%` }}
              transition={{ ease: "easeOut" }}
            />
          </div>
          <p className="mt-2 text-xs tracking-[0.3em] text-amber-200/70">{Math.round(progress)}%</p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
