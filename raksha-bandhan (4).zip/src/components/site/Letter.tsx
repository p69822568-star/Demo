"use client";

import { SectionHeading, SectionWrap, Reveal } from "./Primitives";

export default function Letter() {
  return (
    <SectionWrap id="letter">
      <SectionHeading
        eyebrow="from the heart"
        title={<>An Emotional <span className="gradient-gold-text">Letter</span></>}
        subtitle="Words straight from Akash Bhai & Banti Bhai to their sisters."
      />

      <Reveal>
        <div className="glass-strong relative mx-auto max-w-3xl rounded-3xl p-7 md:p-12">
          <div className="pointer-events-none absolute -left-3 -top-6 font-script text-7xl text-amber-300/30">“</div>

          <div className="space-y-5 font-display text-[1.05rem] leading-relaxed text-amber-50/90 md:text-lg">
            <p>
              To my dearest <span className="text-glow-gold">Lucky Di</span>,{" "}
              <span className="text-glow-gold">Vicky Di</span>,{" "}
              <span className="text-glow-gold">Sapna</span>,{" "}
              <span className="text-glow-gold">Neha</span> and{" "}
              <span className="text-glow-gold">Kalpan</span> ❤️
            </p>
            <p>
              I still remember the little hands that tied my very first Rakhi — and somehow,
              those same hands have held me together ever since. You fed me when I was small,
              scolded me when I was stubborn, believed in me when I doubted myself, and protected
              me in ways I am only beginning to understand.
            </p>
            <p>
              Lucky Di, your care is my safe place. Vicky Di, your strength inspires me. Sapna,
              your laughter is the music of our home. Neha, your sweetness makes every day softer.
              And Kalpan, your quiet love holds us all together.
            </p>
            <p>
              People say Raksha Bandhan is about a brother protecting his sister. But the truth is,
              you protected me first — with your love, your sacrifices, and your endless patience.
              No distance, no silence, no passing year will ever loosen this thread between us.
            </p>
            <p className="font-script text-2xl text-rose-200 md:text-3xl">
              Thank you for always protecting me with your love.
            </p>
          </div>

          <div className="mt-8 text-right">
            <p className="text-sm text-amber-200/70">Forever your little brothers,</p>
            <p className="font-script text-3xl text-glow-gold">Akash Bhai &amp; Banti Bhai</p>
          </div>
        </div>
      </Reveal>
    </SectionWrap>
  );
}
