"use client";

import { motion } from "framer-motion";
import { SectionHeading, SectionWrap } from "./Primitives";

export type TimelineEvent = {
  id: string;
  year: string;
  title: string;
  description: string;
  icon: string;
};

export default function JourneyTimeline({ events }: { events: TimelineEvent[] }) {
  return (
    <SectionWrap id="journey">
      <SectionHeading
        eyebrow="through the years"
        title={<>Our <span className="gradient-gold-text">Journey</span></>}
        subtitle="Every chapter of our story — from tiny hands to forever dreams."
      />

      <div className="relative mx-auto max-w-4xl">
        {/* vertical line */}
        <div className="absolute left-4 top-0 h-full w-px bg-gradient-to-b from-transparent via-amber-300/50 to-transparent md:left-1/2 md:-translate-x-1/2" />

        {events.map((e, i) => {
          const left = i % 2 === 0;
          return (
            <motion.div
              key={e.id}
              className="relative mb-10"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: 0.05 }}
            >
              {/* node */}
              <span className="absolute left-4 top-1 z-10 grid h-9 w-9 -translate-x-1/2 place-items-center rounded-full border border-amber-300/50 bg-[#0c0820] text-base shadow-[0_0_18px_rgba(245,197,66,0.5)] md:left-1/2">
                {e.icon}
              </span>

              <div className="md:grid md:grid-cols-2 md:gap-12">
                <div
                  className={`pl-12 md:pl-0 ${
                    left ? "md:pr-12 md:text-right" : "md:col-start-2 md:pl-12"
                  }`}
                >
                  <div className="glass-card rounded-2xl p-5">
                    <span className="font-script text-xl text-rose-300">{e.year}</span>
                    <h3 className="font-display mt-1 text-xl font-bold text-amber-100">{e.title}</h3>
                    <p className="mt-2 text-sm text-amber-100/70">{e.description}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </SectionWrap>
  );
}
