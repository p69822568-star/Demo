"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { SectionHeading, SectionWrap } from "./Primitives";

function getRemaining(target: Date) {
  const diff = Math.max(0, target.getTime() - Date.now());
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return { days, hours, minutes, seconds };
}

export default function CountdownTimer({ target }: { target: number }) {
  const [t, setT] = useState(() => getRemaining(new Date(target)));

  useEffect(() => {
    const id = setInterval(() => setT(getRemaining(new Date(target))), 1000);
    return () => clearInterval(id);
  }, [target]);

  const units = [
    { label: "Days", value: t.days },
    { label: "Hours", value: t.hours },
    { label: "Minutes", value: t.minutes },
    { label: "Seconds", value: t.seconds },
  ];

  return (
    <SectionWrap id="countdown">
      <SectionHeading
        eyebrow="the next sacred day"
        title={<>Countdown to <span className="gradient-gold-text">Raksha Bandhan</span></>}
        subtitle={`Marking the next full moon of Shravan — ${new Date(target).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}.`}
      />

      <div className="mx-auto grid max-w-2xl grid-cols-2 gap-4 sm:grid-cols-4">
        {units.map((u, i) => (
          <motion.div
            key={u.label}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass-strong anim-pulse-glow rounded-2xl py-6 text-center"
          >
            <motion.div
              key={u.value}
              initial={{ scale: 1.3, opacity: 0.4 }}
              animate={{ scale: 1, opacity: 1 }}
              className="font-display text-5xl font-black gradient-gold-text"
            >
              {String(u.value).padStart(2, "0")}
            </motion.div>
            <div className="mt-1 text-xs uppercase tracking-widest text-amber-200/70">{u.label}</div>
          </motion.div>
        ))}
      </div>
    </SectionWrap>
  );
}
