"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { SectionHeading, SectionWrap } from "./Primitives";
import { sfx } from "@/lib/sfx";
import { bigCelebrate } from "@/lib/celebrate";

const REWARDS = [
  "🎁 Unlimited Hugs",
  "🍫 Chocolate Treat",
  "🍕 Pizza Party",
  "🎬 Movie Night",
  "🛍️ Shopping Together",
  "🍦 Ice Cream Date",
  "💰 ₹501 Gift",
  "🍽️ Family Dinner",
  "🤫 Secret Surprise",
  "🤳 Selfie Challenge",
  "✈️ Memory Trip",
  "🎉 Big Surprise Coming Soon",
];

export default function ScratchCard() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [reward] = useState(() => REWARDS[(Math.random() * REWARDS.length) | 0]);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const size = 280;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size * dpr;
    canvas.height = 180 * dpr;
    canvas.style.width = `${size}px`;
    canvas.style.height = `180px`;
    ctx.scale(dpr, dpr);

    // golden cover
    const grad = ctx.createLinearGradient(0, 0, size, 180);
    grad.addColorStop(0, "#d4a017");
    grad.addColorStop(0.5, "#ffe9a8");
    grad.addColorStop(1, "#b8860b");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, 180);

    // shimmer dots
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.4})`;
      ctx.beginPath();
      ctx.arc(Math.random() * size, Math.random() * 180, Math.random() * 2, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = "rgba(40,28,5,0.85)";
    ctx.font = "600 16px Poppins, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("✨ Scratch here ✨", size / 2, 80);
    ctx.font = "12px Poppins, sans-serif";
    ctx.fillText("use your finger / mouse", size / 2, 104);

    ctx.globalCompositeOperation = "destination-out";
    let drawing = false;

    const pos = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const scratch = (x: number, y: number) => {
      ctx.beginPath();
      ctx.arc(x, y, 22, 0, Math.PI * 2);
      ctx.fill();
    };
    const down = (e: PointerEvent) => { drawing = true; const { x, y } = pos(e); scratch(x, y); sfx.sparkle(); };
    const move = (e: PointerEvent) => {
      if (!drawing) return;
      const { x, y } = pos(e);
      scratch(x, y);
      check();
    };
    const up = () => { drawing = false; };

    let lastCheck = 0;
    const check = () => {
      const now = performance.now();
      if (now - lastCheck < 140) return;
      lastCheck = now;
      const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height);
      let cleared = 0;
      for (let i = 3; i < data.length; i += 4 * 60) if (data[i] === 0) cleared++;
      const total = data.length / (4 * 60);
      if (cleared / total > 0.5 && !revealed) {
        setRevealed(true);
        sfx.win();
        bigCelebrate();
      }
    };

    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => {
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
  }, [revealed]);

  return (
    <SectionWrap id="scratch">
      <SectionHeading
        eyebrow="a little treasure"
        title={<>Scratch Card <span className="gradient-gold-text">Surprise</span></>}
        subtitle="Scratch the golden card to reveal your lucky reward."
      />

      <div className="mx-auto flex max-w-md flex-col items-center">
        <div className="frame-gold">
          <div className="relative overflow-hidden rounded-[0.8rem]">
            {/* reward behind */}
            <div className="flex h-[180px] w-[280px] flex-col items-center justify-center bg-[radial-gradient(circle_at_50%_40%,rgba(168,85,247,0.4),rgba(8,6,20,0.95))] text-center">
              <motion.p
                animate={revealed ? { scale: [0.8, 1.1, 1] } : { scale: 0.9 }}
                transition={{ duration: 0.6 }}
                className="font-display px-4 text-2xl font-bold text-glow-gold"
              >
                {reward}
              </motion.p>
              {revealed && (
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-2 flex items-center gap-1 text-xs text-rose-200">
                  <Sparkles className="h-3 w-3" /> Yours, with love
                </motion.p>
              )}
            </div>
            {!revealed && (
              <canvas
                ref={canvasRef}
                className="absolute inset-0 cursor-grab touch-none active:cursor-grabbing"
              />
            )}
          </div>
        </div>
        <p className="mt-4 text-xs text-amber-100/50">Tip: scratch off more than half to unlock it ✨</p>
      </div>
    </SectionWrap>
  );
}
