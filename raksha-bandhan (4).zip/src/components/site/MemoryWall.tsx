"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Send, Loader2 } from "lucide-react";
import { SectionHeading, SectionWrap } from "./Primitives";
import { heartBurst } from "@/lib/celebrate";
import { SEED_WISHES } from "@/lib/seed-data";

export type Wish = { id: string; name: string; message: string; color: string; hearts: number };

const STORAGE_KEY = "rakhi_wishes_v1";

const COLORS = [
  { key: "rose", bg: "from-rose-500/30 to-pink-700/20", dot: "bg-rose-400" },
  { key: "amber", bg: "from-amber-500/30 to-orange-700/20", dot: "bg-amber-400" },
  { key: "violet", bg: "from-violet-500/30 to-purple-700/20", dot: "bg-violet-400" },
  { key: "emerald", bg: "from-emerald-500/30 to-teal-700/20", dot: "bg-emerald-400" },
];
const colorOf = (k: string) => COLORS.find((c) => c.key === k) ?? COLORS[0];

const SEED: Wish[] = SEED_WISHES.map((w, i) => ({ ...w, id: `seed-${i}`, hearts: 0 }));

export default function MemoryWall() {
  const [wishes, setWishes] = useState<Wish[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [color, setColor] = useState("rose");

  useEffect(() => {
    let initial = SEED;
    try {
      const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (Array.isArray(stored) && stored.length) initial = stored;
    } catch {
      /* ignore */
    }
    setWishes(initial);
    setLoading(false);
  }, []);

  // persist helper (browser localStorage — works with zero config)
  const commit = (next: Wish[]) => {
    setWishes(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;
    setSubmitting(true);
    const wish: Wish = {
      id: `local-${Date.now()}`,
      name: name.trim(),
      message: message.trim(),
      color,
      hearts: 0,
    };
    commit([wish, ...wishes]);
    setName("");
    setMessage("");
    setSubmitting(false);
    heartBurst(0.5, 0.7);
  };

  const addHeart = (id: string) => {
    commit(wishes.map((x) => (x.id === id ? { ...x, hearts: x.hearts + 1 } : x)));
  };

  return (
    <SectionWrap id="wall">
      <SectionHeading
        eyebrow="leave a little love"
        title={<>Memory <span className="gradient-gold-text">Wall</span></>}
        subtitle="Write a wish for the siblings. Your note becomes a glowing sticky memory."
      />

      <form onSubmit={submit} className="glass mx-auto mb-10 max-w-2xl rounded-3xl p-5 md:p-7">
        <div className="grid gap-3 sm:grid-cols-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            maxLength={60}
            className="rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-amber-50 placeholder:text-white/30 focus:border-amber-300/50 focus:outline-none"
          />
          <div className="flex items-center gap-2">
            {COLORS.map((c) => (
              <button
                type="button"
                key={c.key}
                onClick={() => setColor(c.key)}
                aria-label={c.key}
                className={`h-8 w-8 rounded-full ${c.dot} transition ${color === c.key ? "ring-2 ring-white ring-offset-2 ring-offset-transparent" : "opacity-60"}`}
              />
            ))}
          </div>
        </div>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={2}
          maxLength={220}
          placeholder="Write your wish or memory…"
          className="mt-3 w-full resize-none rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-amber-50 placeholder:text-white/30 focus:border-amber-300/50 focus:outline-none"
        />
        <div className="mt-3 flex items-center justify-between">
          <span className="text-xs text-white/40">{message.length}/220</span>
          <button type="submit" disabled={submitting} className="btn-gold disabled:opacity-60">
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            Post Wish
          </button>
        </div>
      </form>

      {loading ? (
        <div className="flex justify-center py-10 text-amber-200/60">
          <Loader2 className="h-7 w-7 animate-spin" />
        </div>
      ) : (
        <div className="columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4">
          <AnimatePresence>
            {wishes.map((w, idx) => {
              const c = colorOf(w.color);
              return (
                <motion.div
                  key={w.id}
                  layout
                  initial={{ opacity: 0, scale: 0.8, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ type: "spring", stiffness: 200, damping: 18 }}
                  className={`break-inside-avoid rounded-2xl bg-gradient-to-br ${c.bg} p-5 shadow-xl backdrop-blur-md`}
                  style={{ transform: `rotate(${(idx % 3) - 1}deg)` }}
                >
                  <div className="mb-2 flex items-center justify-between">
                    <span className="font-display font-semibold text-amber-50">{w.name}</span>
                    <span className="text-lg">📌</span>
                  </div>
                  <p className="text-sm text-amber-50/90">{w.message}</p>
                  <button
                    onClick={() => addHeart(w.id)}
                    className="mt-3 inline-flex items-center gap-1 text-rose-300 transition hover:scale-110"
                  >
                    <Heart className="h-4 w-4 fill-rose-300" /> {w.hearts}
                  </button>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </SectionWrap>
  );
}
