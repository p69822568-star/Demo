"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { SectionHeading, SectionWrap } from "./Primitives";
import { WISH_TREE_BLESSINGS } from "@/lib/seed-data";
import { sfx } from "@/lib/sfx";
import { celebrate } from "@/lib/celebrate";

// 100 leaves: cycle through blessings + slight duplication
const LEAVES = Array.from({ length: 100 }, (_, i) => ({
  id: i,
  blessing: WISH_TREE_BLESSINGS[i % WISH_TREE_BLESSINGS.length],
  x: 12 + Math.abs(Math.sin(i * 12.9898) * 1000) % 76, // 12-88%
  y: 8 + Math.abs(Math.cos(i * 78.233) * 1000) % 64, // 8-72%
  delay: (i % 10) * 0.2,
  hue: ["#f5c542", "#a855f7", "#f3b8c8", "#ffd27d", "#ffe9a8"][i % 5],
}));

export default function WishTree() {
  const [active, setActive] = useState<string | null>(null);

  const canopy = useMemo(() => LEAVES, []);
  const seen = useMemo(() => new Set<number>(), []);
  const tapped = seen.size;

  const pick = (leaf: (typeof LEAVES)[number]) => {
    seen.add(leaf.id);
    setActive(leaf.blessing);
    sfx.sparkle();
    if (seen.size % 10 === 0) celebrate();
  };

  return (
    <SectionWrap id="tree">
      <SectionHeading
        eyebrow="a forest of love"
        title={<>The <span className="gradient-gold-text">Wish Tree</span></>}
        subtitle={`Tap a glowing leaf to receive a blessing. ${LEAVES.length - tapped} blessings still waiting for you.`}
      />

      <div className="relative mx-auto aspect-square max-w-xl">
        {/* trunk */}
        <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full">
          <defs>
            <linearGradient id="trunk" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#7a4a06" />
              <stop offset="100%" stopColor="#3a2304" />
            </linearGradient>
            <radialGradient id="canopyGlow">
              <stop offset="0%" stopColor="rgba(245,197,66,0.25)" />
              <stop offset="100%" stopColor="transparent" />
            </radialGradient>
          </defs>
          <ellipse cx="50" cy="40" rx="46" ry="36" fill="url(#canopyGlow)" />
          <path d="M47 100 C46 78, 44 66, 40 56 M53 100 C54 80, 56 68, 60 58 M50 100 L50 64" stroke="url(#trunk)" strokeWidth="3" strokeLinecap="round" fill="none" />
          <path d="M50 70 C40 64, 32 60, 26 58 M50 66 C60 60, 68 56, 74 56" stroke="url(#trunk)" strokeWidth="2.4" strokeLinecap="round" fill="none" />
        </svg>

        {/* leaves */}
        {canopy.map((leaf) => {
          const isSeen = seen.has(leaf.id);
          return (
            <motion.button
              key={leaf.id}
              onClick={() => pick(leaf)}
              className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full"
              style={{ left: `${leaf.x}%`, top: `${leaf.y}%`, background: leaf.hue, boxShadow: `0 0 ${isSeen ? 4 : 12}px ${leaf.hue}` }}
              animate={{ scale: isSeen ? [1, 1.4, 0.6] : [1, 1.25, 1], opacity: isSeen ? 0.35 : 1 }}
              transition={{ duration: 2, repeat: Infinity, delay: leaf.delay }}
              aria-label="Reveal a blessing"
            />
          );
        })}
      </div>

      <AnimatePresence>
        {active && (
          <motion.div
            className="fixed inset-0 z-[150] grid place-items-center bg-black/70 p-6 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActive(null)}
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="glass-strong relative max-w-sm rounded-3xl p-8 text-center"
              onClick={(e) => e.stopPropagation()}
            >
              <button onClick={() => setActive(null)} className="absolute right-4 top-4 text-white/50 hover:text-white">
                <X className="h-5 w-5" />
              </button>
              <span className="text-4xl">🍃</span>
              <p className="font-display mt-3 text-2xl text-glow-gold">{active}</p>
              <p className="mt-2 text-xs text-rose-200/70">a blessing, just for you</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </SectionWrap>
  );
}
