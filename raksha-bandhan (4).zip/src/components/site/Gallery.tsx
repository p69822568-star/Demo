"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, ZoomIn, Heart } from "lucide-react";
import { SectionHeading, SectionWrap, Reveal } from "./Primitives";
import { heartBurst } from "@/lib/celebrate";

export type Photo = { id: string; title: string; caption: string; src: string; category: string };

export default function Gallery({ photos }: { photos: Photo[] }) {
  const [index, setIndex] = useState<number | null>(null);
  const [zoom, setZoom] = useState(false);

  const close = useCallback(() => setIndex(null), []);
  const prev = useCallback(
    () => setIndex((i) => (i === null ? i : (i - 1 + photos.length) % photos.length)),
    [photos.length]
  );
  const next = useCallback(
    () => setIndex((i) => (i === null ? i : (i + 1) % photos.length)),
    [photos.length]
  );

  useEffect(() => {
    if (index === null) return;
    setZoom(false);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [index, close, prev, next]);

  if (photos.length === 0) return null;

  return (
    <SectionWrap id="gallery">
      <SectionHeading
        eyebrow="moments frozen in time"
        title={<>Our <span className="gradient-gold-text">Memory Gallery</span></>}
        subtitle="Every frame glows with a story. Tap any photo to step inside the memory."
      />

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-6">
        {photos.map((p, i) => (
          <Reveal key={p.id} delay={(i % 3) * 0.08}>
            <button
              onClick={() => setIndex(i)}
              className="group block w-full text-left"
              aria-label={`Open ${p.title}`}
            >
              <div className="frame-gold overflow-hidden">
                <div className="relative aspect-[4/3] overflow-hidden rounded-[0.8rem]">
                  <img
                    src={p.src}
                    alt={p.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-80" />
                  <div className="absolute inset-x-0 bottom-0 p-3">
                    <span className="rounded-full bg-black/40 px-2 py-0.5 text-[10px] uppercase tracking-wider text-amber-200">
                      {p.category}
                    </span>
                    <p className="font-display mt-1 text-sm text-white drop-shadow md:text-base">{p.title}</p>
                  </div>
                  <span className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-black/40 text-amber-200 opacity-0 transition group-hover:opacity-100">
                    <ZoomIn className="h-4 w-4" />
                  </span>
                </div>
              </div>
              {/* reflection */}
              <div
                className="mx-auto mt-1 h-10 w-[88%] rounded-b-[40%] opacity-40 blur-[2px] saturate-150"
                style={{ backgroundImage: `url(${p.src})`, backgroundSize: "cover", transform: "scaleY(-1)", maskImage: "linear-gradient(to bottom, black, transparent)", WebkitMaskImage: "linear-gradient(to bottom, black, transparent)" }}
              />
            </button>
          </Reveal>
        ))}
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {index !== null && (
          <motion.div
            className="fixed inset-0 z-[150] flex items-center justify-center bg-black/90 p-4 backdrop-blur-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={close}
          >
            {/* floating hearts */}
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                className="pointer-events-none absolute text-rose-300"
                initial={{ opacity: 0, y: 0, x: `${10 + i * 11}%` }}
                animate={{ opacity: [0, 1, 0], y: [0, -200 - i * 20] }}
                transition={{ duration: 4 + i, repeat: Infinity, delay: i * 0.5 }}
              >
                <Heart className="h-4 w-4 fill-rose-300" />
              </motion.div>
            ))}

            <button onClick={close} className="absolute right-5 top-5 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20" aria-label="Close">
              <X className="h-5 w-5" />
            </button>
            <button onClick={(e) => { e.stopPropagation(); prev(); }} className="absolute left-3 grid h-12 w-12 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20 md:left-6" aria-label="Previous">
              <ChevronLeft className="h-6 w-6" />
            </button>
            <button onClick={(e) => { e.stopPropagation(); next(); }} className="absolute right-3 grid h-12 w-12 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20 md:right-6" aria-label="Next">
              <ChevronRight className="h-6 w-6" />
            </button>

            <motion.figure
              key={photos[index].id}
              className="relative max-h-[85vh] w-full max-w-3xl"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="overflow-hidden rounded-2xl border border-amber-300/30 shadow-[0_0_60px_rgba(245,197,66,0.25)]">
                <motion.img
                  src={photos[index].src}
                  alt={photos[index].title}
                  animate={{ scale: zoom ? 1.6 : 1 }}
                  transition={{ duration: 0.6 }}
                  className={`mx-auto max-h-[72vh] w-auto object-contain ${zoom ? "cursor-zoom-out" : "cursor-zoom-in"}`}
                  onClick={() => setZoom((z) => !z)}
                />
              </div>
              <figcaption className="mt-4 text-center">
                <div className="flex items-center justify-center gap-3">
                  <h3 className="font-display text-2xl text-glow-gold">{photos[index].title}</h3>
                  <button
                    onClick={() => heartBurst(0.5, 0.6)}
                    className="anim-heartbeat text-rose-300"
                    aria-label="Send love"
                  >
                    <Heart className="h-5 w-5 fill-rose-300" />
                  </button>
                </div>
                <p className="mx-auto mt-2 max-w-lg text-sm text-amber-100/70">{photos[index].caption}</p>
                <p className="mt-1 text-xs text-white/40">{index + 1} / {photos.length}</p>
              </figcaption>
            </motion.figure>
          </motion.div>
        )}
      </AnimatePresence>
    </SectionWrap>
  );
}
