"use client";

import { useEffect, useState } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import ParticleField from "./ParticleField";
import Loader from "./Loader";
import MusicPlayer from "./MusicPlayer";
import Hero from "./Hero";
import Gallery, { type Photo } from "./Gallery";
import MemorySlideshow from "./MemorySlideshow";
import JourneyTimeline, { type TimelineEvent } from "./JourneyTimeline";
import Letter from "./Letter";
import Quotes, { type Quote } from "./Quotes";
import Quiz from "./Quiz";
import EmotionalQuestions from "./EmotionalQuestions";
import ScratchCard from "./ScratchCard";
import SpinWheel from "./SpinWheel";
import RakhiCeremony from "./RakhiCeremony";
import CountdownTimer from "./CountdownTimer";
import GiftCorner from "./GiftCorner";
import WishTree from "./WishTree";
import BalloonGame from "./BalloonGame";
import HeartGame from "./HeartGame";
import TreasureHunt from "./TreasureHunt";
import MemoryWall from "./MemoryWall";
import SpecialSurprise from "./SpecialSurprise";
import FinalSurprise from "./FinalSurprise";
import Footer from "./Footer";

const NAV = [
  ["gallery", "Gallery"],
  ["journey", "Journey"],
  ["letter", "Letter"],
  ["quiz", "Fun"],
  ["ceremony", "Ceremony"],
  ["wall", "Wishes"],
];

export default function Experience({
  photos,
  quotes,
  timeline,
  target,
  giftUnlock,
}: {
  photos: Photo[];
  quotes: Quote[];
  timeline: TimelineEvent[];
  target: number;
  giftUnlock: number;
}) {
  const [ready, setReady] = useState(false);
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.3 });

  // lock scroll while the loader is on screen
  useEffect(() => {
    document.body.style.overflow = ready ? "" : "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [ready]);

  return (
    <>
      {!ready && <Loader onComplete={() => setReady(true)} />}

      {/* scroll progress bar */}
      <motion.div
        className="fixed left-0 top-0 z-[130] h-1 origin-left bg-gradient-to-r from-amber-300 via-yellow-200 to-purple-400"
        style={{ scaleX: progress }}
      />

      <ParticleField />
      <MusicPlayer />

      {/* top nav */}
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={ready ? { y: 0, opacity: 1 } : {}}
        transition={{ delay: 0.5, duration: 0.6 }}
        className="fixed inset-x-0 top-0 z-[110] hidden md:block"
      >
        <div className="mx-auto mt-3 flex max-w-5xl items-center justify-between rounded-full glass px-5 py-2.5">
          <a href="#top" className="font-script text-2xl text-rose-200">Rakhi Bond</a>
          <div className="flex items-center gap-5 text-sm text-amber-100/80">
            {NAV.map(([id, label]) => (
              <a key={id} href={`#${id}`} className="transition hover:text-glow-gold">{label}</a>
            ))}
            <a href="/login" className="btn-ghost px-3 py-1.5 text-xs">Dashboard</a>
          </div>
        </div>
      </motion.nav>

      <main id="top">
        <Hero />
        <Gallery photos={photos} />
        <MemorySlideshow photos={photos} />
        <JourneyTimeline events={timeline} />
        <Letter />
        <Quotes quotes={quotes} />
        <Quiz />
        <EmotionalQuestions />
        <ScratchCard />
        <SpinWheel />
        <RakhiCeremony />
        <CountdownTimer target={target} />
        <GiftCorner unlockTime={giftUnlock} />
        <WishTree />
        <BalloonGame />
        <HeartGame />
        <TreasureHunt />
        <MemoryWall />
        <SpecialSurprise />
        <FinalSurprise />
      </main>

      <Footer />
    </>
  );
}
