"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SectionHeading, SectionWrap } from "./Primitives";
import { sfx } from "@/lib/sfx";
import { goldConfetti } from "@/lib/celebrate";

const MESSAGES = [
  "I told you not to click! 😄",
  "Okay okay… you found the secret button. 🤫",
  "Did you know? You're the favourite sister. (Don't tell the others!) 🤫❤️",
  "Mini fireworks activated! 🎆",
  "Remember when we hid behind the sofa? Good times. 🛋️",
  "You just unlocked a virtual hug. 🤗",
  "Click again — there's more love where that came from! 💛",
];

export default function SpecialSurprise() {
  const [msg, setMsg] = useState<string | null>(null);
  const [count, setCount] = useState(0);

  const click = () => {
    const i = count % MESSAGES.length;
    setMsg(MESSAGES[i]);
    setCount((c) => c + 1);
    sfx.sparkle();
    goldConfetti(0.5 + Math.random() * 0.3);
  };

  return (
    <SectionWrap id="dontclick">
      <SectionHeading
        eyebrow="curiosity kills… the boredom"
        title={<>The <span className="gradient-gold-text">Special Surprise</span></>}
      />

      <div className="flex flex-col items-center">
        <motion.button
          onClick={click}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.94 }}
          className="relative rounded-full border border-rose-400/40 bg-rose-500/15 px-8 py-4 font-display text-lg text-rose-100 shadow-[0_0_30px_rgba(232,160,184,0.3)]"
        >
          Don&apos;t Click 😄
        </motion.button>

        <div className="mt-5 h-8">
          <AnimatePresence mode="wait">
            {msg && (
              <motion.p
                key={count}
                initial={{ opacity: 0, y: 12, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -12 }}
                className="text-amber-100/90"
              >
                {msg}
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      </div>
    </SectionWrap>
  );
}
