"use client";

import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.15, delayChildren: 0.3 } },
};
const item = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.9, ease: [0.2, 0.8, 0.2, 1] as const } },
};

function Diya() {
  return (
    <div className="diya anim-float-soft" style={{ animationDelay: `${Math.random()}s` }}>
      <div className="flame" />
      <div className="bowl" />
    </div>
  );
}

export default function Hero() {
  const scrollToGallery = () =>
    document.getElementById("gallery")?.scrollIntoView({ behavior: "smooth" });

  return (
    <header className="relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden px-4 text-center">
      {/* soft moving glow */}
      <motion.div
        className="pointer-events-none absolute h-[70vmin] w-[70vmin] rounded-full bg-[radial-gradient(circle,rgba(168,85,247,0.28),transparent_60%)] blur-3xl"
        animate={{ scale: [1, 1.15, 1], opacity: [0.7, 1, 0.7] }}
        transition={{ duration: 8, repeat: Infinity }}
      />

      {/* Animated Rakhi centerpiece */}
      <motion.div
        initial={{ opacity: 0, scale: 0.6, rotate: -20 }}
        animate={{ opacity: 1, scale: 1, rotate: 0 }}
        transition={{ duration: 1.4, ease: [0.2, 0.8, 0.2, 1] }}
        className="relative mb-8 h-40 w-40 sm:h-52 sm:w-52"
      >
        <div className="absolute inset-0 anim-spin-slow rounded-full border-2 border-dashed border-amber-300/40" />
        <div className="absolute inset-4 anim-spin-rev rounded-full border border-purple-400/30" />
        {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
          <span
            key={i}
            className="absolute left-1/2 top-1/2 h-2.5 w-2.5 rounded-full bg-amber-300"
            style={{
              transform: `rotate(${i * 45}deg) translateY(-${88}px)`,
              boxShadow: "0 0 12px #f5c542",
            }}
          />
        ))}
        <div className="absolute inset-12 rakhi-disc anim-pulse-glow" />
        <div className="absolute inset-[44%] rounded-full bg-amber-100 shadow-[0_0_28px_#ffe9a8]" />
      </motion.div>

      {/* flanking diyas */}
      <div className="pointer-events-none absolute bottom-24 left-6 hidden sm:block md:left-16">
        <Diya />
      </div>
      <div className="pointer-events-none absolute bottom-24 right-6 hidden sm:block md:right-16">
        <Diya />
      </div>

      <motion.div variants={container} initial="hidden" animate="show" className="relative z-10">
        <motion.p variants={item} className="eyebrow text-rose-200">
          with all my heart
        </motion.p>

        <motion.h1
          variants={item}
          className="font-display mt-2 text-5xl font-black leading-[1.05] sm:text-6xl md:text-7xl"
        >
          <span className="gradient-gold-text">Happy</span>{" "}
          <span className="gradient-gold-text">Raksha Bandhan</span>{" "}
          <span className="anim-heartbeat inline-block">❤️</span>
        </motion.h1>

        <motion.p variants={item} className="mx-auto mt-5 max-w-xl text-base text-amber-100/80 md:text-lg">
          A Bond of Love, Protection, Memories and Forever.
        </motion.p>

        <motion.p variants={item} className="mt-4 text-sm tracking-wide text-purple-200/80">
          From <span className="text-glow-gold font-semibold">Akash Bhai &amp; Banti Bhai</span> — for Lucky Di, Vicky Di, Sapna, Neha &amp; Kalpan
        </motion.p>

        <motion.div variants={item} className="mt-9">
          <button onClick={scrollToGallery} className="btn-gold text-base">
            ✨ Open My Surprise
          </button>
        </motion.div>
      </motion.div>

      {/* scroll indicator */}
      <motion.button
        onClick={scrollToGallery}
        className="absolute bottom-7 flex flex-col items-center gap-1 text-amber-200/70"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 1.6, repeat: Infinity }}
        aria-label="Scroll down"
      >
        <span className="text-[11px] uppercase tracking-[0.3em]">Scroll</span>
        <ChevronDown className="h-5 w-5" />
      </motion.button>
    </header>
  );
}
