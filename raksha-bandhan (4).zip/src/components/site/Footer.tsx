"use client";

import { SITE } from "@/lib/constants";

export default function Footer() {
  return (
    <footer className="relative z-10 border-t border-white/10 px-4 py-12 text-center">
      <div className="mx-auto max-w-2xl">
        <div className="mx-auto mb-5 h-12 w-12 rounded-full border border-amber-300/40 grid place-items-center anim-pulse-glow">
          <span className="text-xl">🪔</span>
        </div>
        <p className="font-script text-3xl text-rose-200">A Bond Beyond Words</p>

        <p className="mt-4 text-sm text-amber-100/70">
          Made with <span className="text-rose-400">❤️</span> by{" "}
          <span className="text-glow-gold font-semibold">{SITE.owners}</span>
        </p>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-sm text-amber-100/80">
          <span className="opacity-60">For</span>
          {SITE.sisters.map((s, i) => (
            <span key={s} className="inline-flex items-center gap-1">
              {s} <span className="text-rose-400">❤️</span>
              {i < SITE.sisters.length - 1 && <span className="text-white/20">·</span>}
            </span>
          ))}
        </div>

        <p className="mt-6 text-xs text-white/30">
          © {new Date().getFullYear()} · Crafted with love, light &amp; a little bit of magic. ✨
        </p>
      </div>
    </footer>
  );
}
