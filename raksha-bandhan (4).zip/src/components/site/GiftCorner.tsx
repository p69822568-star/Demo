"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lock, Eye, Gift, KeyRound, Loader2 } from "lucide-react";
import { SectionHeading, SectionWrap, Reveal } from "./Primitives";
import { GIFTS } from "@/lib/constants";
import { celebrate } from "@/lib/celebrate";

export default function GiftCorner({ unlockTime }: { unlockTime: number }) {
  const [now, setNow] = useState(() => Date.now());
  const [preview, setPreview] = useState(false);
  const [pwd, setPwd] = useState("");
  const [checking, setChecking] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const unlocked = now >= unlockTime;
  const showGifts = unlocked || preview;

  useEffect(() => {
    if (unlocked) celebrate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unlocked]);

  const remaining = Math.max(0, unlockTime - now);
  const dd = Math.floor(remaining / 86400000);
  const hh = Math.floor((remaining % 86400000) / 3600000);
  const mm = Math.floor((remaining % 3600000) / 60000);
  const ss = Math.floor((remaining % 60000) / 1000);

  const unlockLabel = new Date(unlockTime).toLocaleString("en-IN", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  const tryPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setChecking(true);
    setErr(null);
    try {
      const res = await fetch("/api/gifts/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pwd }),
      });
      const data = await res.json();
      if (data.ok) {
        setPreview(true);
        celebrate();
        setPwd("");
      } else {
        setErr("Galat password — phir try karo.");
      }
    } catch {
      setErr("Kuch gadbad ho gayi, dobara try karo.");
    } finally {
      setChecking(false);
    }
  };

  return (
    <SectionWrap id="gifts">
      <SectionHeading
        eyebrow="a little surprise"
        title={<>The <span className="gradient-gold-text">Gift Corner</span></>}
        subtitle={
          unlocked
            ? "Tap to unwrap your gift, dear sister 🎁"
            : "Your gifts are wrapped & waiting — they open on Raksha Bandhan at 12:00 noon."
        }
      />

      {/* lock / countdown / password */}
      <Reveal>
        <div className="mx-auto mb-10 max-w-xl rounded-2xl glass p-5 text-center">
          {unlocked ? (
            <p className="flex items-center justify-center gap-2 text-emerald-300">
              <Gift className="h-5 w-5" /> The gifts are unlocked! Enjoy 🎉
            </p>
          ) : preview ? (
            <p className="flex items-center justify-center gap-2 text-amber-200">
              <Eye className="h-5 w-5" /> Admin preview on — gifts ab dikh rahe hain.
            </p>
          ) : (
            <>
              <p className="flex items-center justify-center gap-2 text-amber-100/80">
                <Lock className="h-4 w-4" /> Locked until <b className="text-glow-gold">{unlockLabel}</b>
              </p>
              <div className="mt-3 flex justify-center gap-2 text-sm">
                {[
                  ["Days", dd],
                  ["Hrs", hh],
                  ["Min", mm],
                  ["Sec", ss],
                ].map(([label, val]) => (
                  <div key={label as string} className="rounded-xl bg-black/30 px-3 py-2">
                    <span className="font-display text-lg text-glow-gold">{String(val).padStart(2, "0")}</span>
                    <span className="ml-1 text-[10px] uppercase text-amber-200/60">{label}</span>
                  </div>
                ))}
              </div>

              {/* admin password section */}
              <form onSubmit={tryPassword} className="mx-auto mt-5 flex max-w-xs items-center gap-2">
                <div className="relative flex-1">
                  <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-amber-300/70" />
                  <input
                    type="password"
                    value={pwd}
                    onChange={(e) => setPwd(e.target.value)}
                    placeholder="Admin password"
                    autoComplete="off"
                    className="w-full rounded-full border border-white/10 bg-black/30 py-2 pl-9 pr-3 text-sm text-amber-50 placeholder:text-white/30 focus:border-amber-300/50 focus:outline-none"
                  />
                </div>
                <button type="submit" disabled={checking} className="btn-gold px-4 py-2 text-sm disabled:opacity-60">
                  {checking ? <Loader2 className="h-4 w-4 animate-spin" /> : "Unlock"}
                </button>
              </form>
              {err && <p className="mt-2 text-xs text-rose-300">{err}</p>}
            </>
          )}
        </div>
      </Reveal>

      {/* gift cards */}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {GIFTS.map((g, i) => (
          <Reveal key={g.sister} delay={i * 0.08}>
            <GiftCard gift={g} locked={!showGifts} />
          </Reveal>
        ))}
      </div>
    </SectionWrap>
  );
}

function GiftCard({ gift, locked }: { gift: (typeof GIFTS)[number]; locked: boolean }) {
  const [opened, setOpened] = useState(false);
  useEffect(() => {
    setOpened(!locked);
  }, [locked]);

  return (
    <motion.div
      whileHover={{ y: -6 }}
      className={`relative h-full overflow-hidden rounded-2xl bg-gradient-to-br ${gift.color} p-6 text-center backdrop-blur-md`}
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.12),transparent_60%)]" />
      <p className="font-script text-2xl text-rose-200">{gift.sister}</p>

      <AnimatePresence mode="wait">
        {locked ? (
          <motion.div key="locked" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mt-4">
            <div className="mx-auto grid h-24 w-24 place-items-center rounded-full border border-white/15 bg-black/30 text-4xl">
              🔒
            </div>
            <p className="mt-3 text-xs text-amber-100/60">Unlocks on Rakhi day at 12 noon</p>
          </motion.div>
        ) : (
          <motion.button
            key="open"
            onClick={() => {
              setOpened(true);
              celebrate();
            }}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-4 block w-full"
          >
            {!opened ? (
              <div className="mx-auto grid h-24 w-24 place-items-center rounded-2xl border border-amber-300/40 bg-amber-300/10 text-5xl anim-pulse-glow">
                🎁
              </div>
            ) : (
              <motion.div
                initial={{ scale: 0.4, rotate: -12, opacity: 0 }}
                animate={{ scale: 1, rotate: 0, opacity: 1 }}
                transition={{ type: "spring", stiffness: 160 }}
                className="mx-auto grid h-24 w-24 place-items-center rounded-2xl bg-black/30 text-6xl"
              >
                {gift.emoji}
              </motion.div>
            )}
            <p className="font-display mt-3 text-lg text-glow-gold">{opened ? gift.gift : "Tap to unwrap 🎁"}</p>
            {opened && <p className="mt-2 text-xs text-amber-100/75">{gift.note}</p>}
          </motion.button>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
