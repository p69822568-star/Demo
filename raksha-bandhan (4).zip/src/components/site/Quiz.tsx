"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RotateCcw, Sparkles } from "lucide-react";
import { SectionHeading, SectionWrap } from "./Primitives";
import { sfx } from "@/lib/sfx";
import { celebrate } from "@/lib/celebrate";

type Option = { name: string; msg: string };
type Question = { q: string; emoji: string; options: Option[] };

const QUESTIONS: Question[] = [
  {
    q: "Who is the most caring sister?",
    emoji: "🤱",
    options: [
      { name: "Lucky Di", msg: "Lucky Di — the original guardian angel! 🛡️" },
      { name: "Vicky Di", msg: "Vicky Di cares like a second mother 🌷" },
      { name: "Sapna", msg: "Sapna's hugs heal everything 🤗" },
      { name: "Neha", msg: "Neha secretly checks on everyone 💌" },
    ],
  },
  {
    q: "Who scolds Akash the most?",
    emoji: "😤",
    options: [
      { name: "Vicky Di", msg: "Vicky Di — because she knows he can do better 😅" },
      { name: "Lucky Di", msg: "Lucky Di's scolding comes wrapped in love ❤️" },
      { name: "Sapna", msg: "Sapna roasts him lovingly 🔥" },
      { name: "Kalpan", msg: "Kalpan gives the silent eyebrow treatment 👀" },
    ],
  },
  {
    q: "Who laughs the loudest?",
    emoji: "😂",
    options: [
      { name: "Sapna", msg: "Sapna's laugh is contagious — the whole house cracks up!" },
      { name: "Neha", msg: "Neha giggles until everyone else joins 🤭" },
      { name: "Lucky Di", msg: "Lucky Di's laugh = pure joy 🌈" },
      { name: "Vicky Di", msg: "Vicky Di snort-laughs the best 😆" },
    ],
  },
  {
    q: "Who always gives the best advice?",
    emoji: "🧠",
    options: [
      { name: "Kalpan", msg: "Kalpan drops wisdom bombs like a pro 🦉" },
      { name: "Lucky Di", msg: "Lucky Di always knows what to say 💡" },
      { name: "Vicky Di", msg: "Vicky Di is the family strategist ♟️" },
      { name: "Neha", msg: "Neha listens first, advises best 👂" },
    ],
  },
  {
    q: "Who makes the tastiest food?",
    emoji: "🍛",
    options: [
      { name: "Sapna", msg: "Sapna's kitchen = a five-star home 🍲" },
      { name: "Neha", msg: "Neha's chai is legendary ☕" },
      { name: "Vicky Di", msg: "Vicky Di cooks with pure love 🥰" },
      { name: "Lucky Di", msg: "Lucky Di's feasts are unbeatable 🎉" },
    ],
  },
  {
    q: "Who protects everyone?",
    emoji: "🛡️",
    options: [
      { name: "Vicky Di", msg: "Vicky Di — the family's fierce shield ⚔️" },
      { name: "Lucky Di", msg: "Lucky Di stands like a wall for us all 🧱" },
      { name: "Kalpan", msg: "Kalpan quietly watches over everyone 🌙" },
      { name: "Sapna", msg: "Sapna fights for the people she loves 🔥" },
    ],
  },
  {
    q: "Who wins family arguments?",
    emoji: "🏆",
    options: [
      { name: "Vicky Di", msg: "Vicky Di wins with pure logic 🎯" },
      { name: "Lucky Di", msg: "Lucky Di wins with the 'I'm the eldest' card 👑" },
      { name: "Neha", msg: "Neha wins by being too cute to argue with 🌸" },
      { name: "Sapna", msg: "Sapna wins with the final-word technique 😎" },
    ],
  },
  {
    q: "Who gets emotional first?",
    emoji: "🥹",
    options: [
      { name: "Neha", msg: "Neha cries at every family moment 🥲" },
      { name: "Sapna", msg: "Sapna tears up watching old photos 📸" },
      { name: "Lucky Di", msg: "Lucky Di gets misty at farewells 🌧️" },
      { name: "Kalpan", msg: "Kalpan hides it, but we all know 🤍" },
    ],
  },
  {
    q: "Who always supports your dreams?",
    emoji: "🌟",
    options: [
      { name: "Kalpan", msg: "Kalpan believes before anyone else does ✨" },
      { name: "Lucky Di", msg: "Lucky Di is your #1 cheerleader 📣" },
      { name: "Vicky Di", msg: "Vicky Di pushes you to aim higher 🚀" },
      { name: "Sapna", msg: "Sapna celebrates every tiny win 🎊" },
    ],
  },
];

function shuffle<T>(arr: T[]) {
  return [...arr].sort(() => Math.random() - 0.5);
}

export default function Quiz() {
  const [round, setRound] = useState(shuffle(QUESTIONS).slice(0, 6));
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<Option | null>(null);
  const [answered, setAnswered] = useState(0);
  const [done, setDone] = useState(false);

  const restart = () => {
    setRound(shuffle(QUESTIONS).slice(0, 6));
    setStep(0);
    setPicked(null);
    setAnswered(0);
    setDone(false);
  };

  const pick = (opt: Option) => {
    if (picked) return;
    setPicked(opt);
    setAnswered((a) => a + 1);
    sfx.win();
    celebrate();
    setTimeout(() => {
      if (step + 1 >= round.length) {
        setDone(true);
      } else {
        setStep((s) => s + 1);
        setPicked(null);
      }
    }, 1700);
  };

  const current = round[step];
  const score = Math.round((answered / round.length) * 100);

  return (
    <SectionWrap id="quiz">
      <SectionHeading
        eyebrow="a little fun"
        title={<>Sister <span className="gradient-gold-text">Quiz</span></>}
        subtitle="There are no wrong answers — every sister is a winner here."
      />

      <div className="mx-auto max-w-2xl">
        <AnimatePresence mode="wait">
          {!done ? (
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 60 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -60 }}
              transition={{ duration: 0.5 }}
              className="glass-strong rounded-3xl p-7 md:p-10"
            >
              <div className="mb-4 flex items-center justify-between text-xs text-amber-200/70">
                <span>Question {step + 1} / {round.length}</span>
                <span className="flex items-center gap-1"><Sparkles className="h-3.5 w-3.5" /> {answered} answered</span>
              </div>
              <div className="mb-2 h-1 w-full overflow-hidden rounded-full bg-white/10">
                <div className="h-full rounded-full bg-gradient-to-r from-amber-300 to-purple-400 transition-all" style={{ width: `${((step) / round.length) * 100}%` }} />
              </div>

              <h3 className="font-display mt-5 text-2xl text-amber-50 md:text-3xl">
                <span className="mr-2">{current.emoji}</span>{current.q}
              </h3>

              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                {shuffle(current.options).map((opt) => {
                  const revealed = picked !== null;
                  const isPicked = picked?.name === opt.name;
                  return (
                    <button
                      key={opt.name}
                      onClick={() => pick(opt)}
                      disabled={revealed}
                      className={`rounded-2xl border px-4 py-4 text-left text-sm transition-all ${
                        isPicked
                          ? "border-amber-300 bg-amber-300/20 text-amber-100 scale-[1.02]"
                          : revealed
                          ? "border-white/10 bg-white/5 opacity-50"
                          : "border-white/10 bg-white/5 hover:border-amber-300/50 hover:bg-amber-300/10"
                      }`}
                    >
                      <span className="font-semibold">{opt.name}</span>
                      {isPicked && (
                        <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-1 block text-xs text-amber-200/80">
                          {opt.msg}
                        </motion.span>
                      )}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="glass-strong rounded-3xl p-10 text-center"
            >
              <p className="font-script text-3xl text-rose-200">Your score</p>
              <motion.p
                className="font-display my-2 text-7xl font-black gradient-gold-text"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 140 }}
              >
                {score}
              </motion.p>
              <p className="text-amber-100/80">Every answer is a tribute to love. You & your sisters are unbeatable! 💞</p>
              <button onClick={restart} className="btn-ghost mt-6">
                <RotateCcw className="h-4 w-4" /> Play Again
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </SectionWrap>
  );
}
