"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SectionHeading, SectionWrap } from "./Primitives";
import type { Photo } from "./Gallery";

export default function MemorySlideshow({ photos }: { photos: Photo[] }) {
  const [i, setI] = useState(0);

  useEffect(() => {
    if (photos.length <= 1) return;
    const id = setInterval(() => setI((p) => (p + 1) % photos.length), 4200);
    return () => clearInterval(id);
  }, [photos.length]);

  if (photos.length === 0) return null;
  const p = photos[i];

  return (
    <SectionWrap id="slideshow">
      <SectionHeading
        eyebrow="let the memories play"
        title={<>Memory <span className="gradient-gold-text">Slideshow</span></>}
        subtitle="Sit back and watch our story drift by, one golden frame at a time."
      />

      <div className="relative mx-auto aspect-[16/9] max-w-4xl overflow-hidden rounded-3xl border border-amber-300/20 shadow-[0_0_60px_rgba(245,197,66,0.18)]">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={p.id}
            initial={{ opacity: 0, scale: 1.15 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ opacity: { duration: 1.2 }, scale: { duration: 4.5, ease: "linear" } }}
            className="absolute inset-0"
          >
            <img src={p.src} alt={p.title} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
          </motion.div>
        </AnimatePresence>

        <div className="absolute bottom-0 left-0 p-6 text-left">
          <motion.p
            key={p.title}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="font-display text-2xl text-glow-gold md:text-3xl"
          >
            {p.title}
          </motion.p>
          <p className="text-sm text-amber-100/80">{p.caption}</p>
        </div>

        {/* progress dots */}
        <div className="absolute right-4 top-4 flex gap-1.5">
          {photos.map((_, idx) => (
            <span key={idx} className={`h-1.5 rounded-full transition-all ${idx === i ? "w-6 bg-amber-300" : "w-1.5 bg-white/40"}`} />
          ))}
        </div>
      </div>
    </SectionWrap>
  );
}
