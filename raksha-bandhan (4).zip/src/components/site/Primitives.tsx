"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

/** Fade + rise into view on scroll. */
export function Reveal({
  children,
  delay = 0,
  className = "",
  y = 38,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  y?: number;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.8, delay, ease: [0.2, 0.8, 0.2, 1] }}
    >
      {children}
    </motion.div>
  );
}

/** Consistent animated section heading. */
export function SectionHeading({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: ReactNode;
  subtitle?: string;
}) {
  return (
    <div className="mx-auto mb-12 max-w-2xl text-center">
      <Reveal>
        <p className="eyebrow">{eyebrow}</p>
      </Reveal>
      <Reveal delay={0.08}>
        <h2 className="font-display mt-1 text-4xl font-bold leading-tight md:text-5xl">{title}</h2>
      </Reveal>
      {subtitle && (
        <Reveal delay={0.16}>
          <p className="mt-4 text-sm text-amber-100/60 md:text-base">{subtitle}</p>
        </Reveal>
      )}
      <Reveal delay={0.2}>
        <div className="mx-auto mt-6 h-px w-32 divider-glow" />
      </Reveal>
    </div>
  );
}

export function SectionWrap({
  id,
  children,
  className = "",
}: {
  id?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={`section-pad relative z-10 ${className}`}>
      <div className="mx-auto max-w-6xl">{children}</div>
    </section>
  );
}
