"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Play, RotateCcw } from "lucide-react";
import { SectionHeading, SectionWrap } from "./Primitives";
import { sfx } from "@/lib/sfx";
import { celebrate } from "@/lib/celebrate";

type H = { id: number; x: number; y: number; vy: number; size: number; emoji: string };

export default function HeartGame() {
  const [playing, setPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [missed, setMissed] = useState(0);
  const [hearts, setHearts] = useState<H[]>([]);
  const areaRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(0);
  const scoreRef = useRef(0);

  useEffect(() => { scoreRef.current = score; }, [score]);

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = (now - last) / 16.67;
      last = now;
      setHearts((hs) => {
        let outOfBounds = 0;
        const next = hs
          .map((h) => ({ ...h, y: h.y + h.vy * dt }))
          .filter((h) => {
            if (h.y > 100) { outOfBounds++; return false; }
            return true;
          });
        if (outOfBounds) setMissed((m) => m + outOfBounds);
        return next;
      });
      raf = requestAnimationFrame(tick);
    };
    const spawn = setInterval(() => {
      const emoji = ["❤️", "💛", "💖", "💕", "🧡"][Math.floor(Math.random() * 5)];
      setHearts((hs) => [
        ...hs,
        { id: idRef.current++, x: 6 + Math.random() * 88, y: -8, vy: 0.35 + Math.random() * 0.5, size: 26 + Math.random() * 18, emoji },
      ]);
    }, 650);
    raf = requestAnimationFrame(tick);
    return () => { clearInterval(spawn); cancelAnimationFrame(raf); };
  }, [playing]);

  const catchHeart = (id: number, clientX: number, clientY: number) => {
    setHearts((hs) => hs.filter((h) => h.id !== id));
    const next = scoreRef.current + 1;
    setScore(next);
    sfx.ding();
    if (next % 10 === 0) celebrate();
  };

  const reset = () => { setScore(0); setMissed(0); setHearts([]); setPlaying(true); };

  return (
    <SectionWrap id="hearts">
      <SectionHeading
        eyebrow="catch the love"
        title={<>Heart Catch <span className="gradient-gold-text">Game</span></>}
        subtitle="Tap the falling hearts to catch them. How much love can you gather?"
      />

      <div className="mx-auto max-w-2xl">
        <div className="mb-4 flex items-center justify-between">
          <span className="glass rounded-full px-4 py-1.5 text-sm text-amber-100">
            Caught: <b className="text-glow-gold">{score}</b> <span className="mx-1 text-white/30">·</span> Missed: <b className="text-rose-300">{missed}</b>
          </span>
          {!playing ? (
            <button onClick={() => setPlaying(true)} className="btn-gold"><Play className="h-4 w-4" /> Start</button>
          ) : (
            <button onClick={reset} className="btn-ghost"><RotateCcw className="h-4 w-4" /> Reset</button>
          )}
        </div>

        <div
          ref={areaRef}
          className="relative h-80 overflow-hidden rounded-3xl border border-white/10 bg-[radial-gradient(circle_at_50%_-20%,rgba(245,197,66,0.18),rgba(4,2,10,0.6))]"
        >
          {!playing && (
            <div className="absolute inset-0 grid place-items-center text-center">
              <div>
                <p className="text-5xl">💖</p>
                <p className="mt-2 text-amber-100/70">Press Start and catch the falling hearts!</p>
              </div>
            </div>
          )}

          {hearts.map((h) => (
            <motion.button
              key={h.id}
              onClick={(e) => catchHeart(h.id, e.clientX, e.clientY)}
              className="absolute -translate-x-1/2 select-none"
              style={{ left: `${h.x}%`, top: `${h.y}%`, fontSize: h.size, lineHeight: 1 }}
              whileTap={{ scale: 1.5 }}
              aria-label="Catch heart"
            >
              {h.emoji}
            </motion.button>
          ))}
        </div>
      </div>
    </SectionWrap>
  );
}
