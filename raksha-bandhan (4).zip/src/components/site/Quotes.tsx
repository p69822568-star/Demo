"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Quote as QuoteIcon } from "lucide-react";
import { SectionHeading, SectionWrap } from "./Primitives";

export type Quote = { id: string; text: string; author: string | null };

export default function Quotes({ quotes }: { quotes: Quote[] }) {
  const [i, setI] = useState(0);

  useEffect(() => {
    if (quotes.length === 0) return;
    const id = setInterval(() => setI((p) => (p + 1) % quotes.length), 5000);
    return () => clearInterval(id);
  }, [quotes.length]);

  if (quotes.length === 0) return null;
  const q = quotes[i];

  return (
    <SectionWrap id="quotes">
      <SectionHeading
        eyebrow="words to remember"
        title={<>Memory <span className="gradient-gold-text">Quotes</span></>}
        subtitle="A little light for the heart, changing every few seconds."
      />

      <div className="relative mx-auto flex min-h-[220px] max-w-3xl items-center justify-center">
        <div className="pointer-events-none absolute inset-0 rounded-full bg-[radial-gradient(circle,rgba(245,197,66,0.12),transparent_70%)] blur-2xl" />
        <AnimatePresence mode="wait">
          <motion.figure
            key={q.id}
            initial={{ opacity: 0, y: 24, filter: "blur(8px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -24, filter: "blur(8px)" }}
            transition={{ duration: 0.7 }}
            className="glass relative rounded-3xl px-8 py-10 text-center md:px-14"
          >
            <QuoteIcon className="mx-auto mb-4 h-8 w-8 text-amber-300/70" />
            <blockquote className="font-display text-2xl leading-snug text-amber-50 md:text-3xl">
              “{q.text}”
            </blockquote>
            {q.author && (
              <figcaption className="font-script mt-4 text-2xl text-rose-200">— {q.author}</figcaption>
            )}
          </motion.figure>
        </AnimatePresence>
      </div>

      {/* dots */}
      <div className="mt-6 flex justify-center gap-2">
        {quotes.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setI(idx)}
            aria-label={`Quote ${idx + 1}`}
            className={`h-2 rounded-full transition-all ${idx === i ? "w-6 bg-amber-300" : "w-2 bg-white/20"}`}
          />
        ))}
      </div>
    </SectionWrap>
  );
}
