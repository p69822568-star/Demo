"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SectionHeading, SectionWrap } from "./Primitives";
import { sfx } from "@/lib/sfx";
import { bigCelebrate } from "@/lib/celebrate";

const TOTAL = 6;
// positions (percent) inside the play area
const SPOTS = [
  { id: 0, x: 12, y: 22 },
  { id: 1, x: 78, y: 18 },
  { id: 2, x: 30, y: 64 },
  { id: 3, x: 62, y: 70 },
  { id: 4, x: 88, y: 55 },
  { id: 5, x: 8, y: 78 },
];

export default function TreasureHunt() {
  const [found, setFound] = useState<Set<number>>(new Set());

  const find = (id: number) => {
    if (found.has(id)) return;
    sfx.ding();
    const next = new Set(found);
    next.add(id);
    setFound(next);
    if (next.size === TOTAL) bigCelebrate();
  };

  const reset = () => setFound(new Set());

  return (
    <SectionWrap id="treasure">
      <SectionHeading
        eyebrow="a hidden secret"
        title={<>Rakhi <span className="gradient-gold-text">Treasure Hunt</span></>}
        subtitle={`Find all ${TOTAL} hidden rakhi symbols to unlock a secret message. (${found.size}/${TOTAL} found)`}
      />

      <div className="relative mx-auto h-72 max-w-3xl overflow-hidden rounded-3xl border border-white/10 bg-[radial-gradient(circle_at_30%_20%,rgba(109,40,217,0.3),rgba(4,2,10,0.7))]">
        {/* decoy glow points to make hunting fun */}
        {Array.from({ length: 26 }).map((_, i) => (
          <span
            key={i}
            className="absolute h-1 w-1 rounded-full bg-amber-200/40"
            style={{ left: `${(i * 37) % 100}%`, top: `${(i * 53) % 100}%` }}
          />
        ))}

        {SPOTS.map((s) => {
          const isFound = found.has(s.id);
          return (
            <button
              key={s.id}
              onClick={() => find(s.id)}
              className="absolute grid h-9 w-9 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full text-lg transition hover:scale-125"
              style={{ left: `${s.x}%`, top: `${s.y}%`, opacity: isFound ? 0.25 : 0.9 }}
              aria-label="Hidden rakhi"
            >
              {isFound ? "✅" : (
                <span className="anim-pulse-glow rounded-full bg-amber-300/20 px-1.5 py-0.5 text-amber-200/80 blur-[1px] hover:blur-0">
                  🧿
                </span>
              )}
            </button>
          );
        })}
      </div>

      <AnimatePresence>
        {found.size === TOTAL && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-strong mx-auto mt-6 max-w-xl rounded-3xl p-8 text-center"
          >
            <p className="text-4xl">🎉</p>
            <p className="font-display mt-2 text-2xl text-glow-gold">Secret unlocked!</p>
            <p className="mt-2 text-amber-100/80">
              “No matter where life takes us, the thread between us will never break.
              You are my forever treasure.” ❤️
            </p>
            <button onClick={reset} className="btn-ghost mt-5">Play again</button>
          </motion.div>
        )}
      </AnimatePresence>
    </SectionWrap>
  );
}
