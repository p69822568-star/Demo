"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, VolumeX, Music, Pause, Play } from "lucide-react";
import { SONG_URL } from "@/lib/constants";

/**
 * Floating glass music player.
 * Attempts gentle autoplay; resumes on first user gesture (browser policy).
 * Listens for the custom "rakhi:enter" event from the loader to start.
 */
export default function MusicPlayer() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.55);
  const [open, setOpen] = useState(false);
  const [label, setLabel] = useState("Our Song · Raksha Bandhan");

  const tryPlay = async () => {
    const a = audioRef.current;
    if (!a) return;
    a.volume = 0;
    try {
      await a.play();
      setPlaying(true);
      // soft ramp-up
      let v = 0;
      const ramp = setInterval(() => {
        v = Math.min(volume, v + 0.05);
        a.volume = muted ? 0 : v;
        if (v >= volume) clearInterval(ramp);
      }, 90);
    } catch {
      setPlaying(false);
    }
  };

  useEffect(() => {
    const onEnter = () => tryPlay();
    const onGesture = () => {
      if (!playing) tryPlay();
      window.removeEventListener("pointerdown", onGesture);
    };
    window.addEventListener("rakhi:enter", onEnter);
    window.addEventListener("pointerdown", onGesture);
    return () => {
      window.removeEventListener("rakhi:enter", onEnter);
      window.removeEventListener("pointerdown", onGesture);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) {
      a.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    } else {
      a.pause();
      setPlaying(false);
    }
  };

  const toggleMute = () => {
    const a = audioRef.current;
    if (!a) return;
    const m = !muted;
    setMuted(m);
    a.volume = m ? 0 : volume;
  };

  const onVolume = (val: number) => {
    setVolume(val);
    if (audioRef.current && !muted) audioRef.current.volume = val;
  };

  return (
    <>
      <audio ref={audioRef} src={SONG_URL} loop preload="auto" />

      <motion.div
        className="fixed bottom-5 right-5 z-[120] flex items-center gap-2"
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1.2, type: "spring", stiffness: 120 }}
      >
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, x: 20, width: 0 }}
              animate={{ opacity: 1, x: 0, width: "auto" }}
              exit={{ opacity: 0, x: 20, width: 0 }}
              className="glass-strong flex items-center gap-3 rounded-full py-2 pl-4 pr-3"
            >
              <div className="hidden items-center gap-2 sm:flex">
                <Music className="h-4 w-4 text-amber-300" />
                <span className="max-w-[120px] truncate text-xs text-amber-100/80">{label}</span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={volume}
                onChange={(e) => onVolume(parseFloat(e.target.value))}
                className="h-1 w-20 cursor-pointer accent-amber-300"
                aria-label="Volume"
              />
              <button onClick={toggleMute} className="text-amber-200/80 hover:text-amber-100" aria-label="Mute">
                {muted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <button
          onClick={() => (open ? toggle() : (setOpen(true), toggle()))}
          className="glass-strong anim-pulse-glow flex h-12 w-12 items-center justify-center rounded-full text-amber-200"
          aria-label="Play music"
        >
          {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 translate-x-0.5" />}
        </button>
      </motion.div>
    </>
  );
}
