"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, RotateCcw } from "lucide-react";
import { SectionHeading, SectionWrap } from "./Primitives";
import { sfx } from "@/lib/sfx";
import { celebrate } from "@/lib/celebrate";

const REVEALS = [
  "💫 Memory: stealing sweets together",
  "💞 Quote: our bond never fades",
  "🎁 Gift: a surprise hug!",
  "🍫 Treat: chocolate time",
  "😆 Memory: that one family joke",
  "✨ Quote: sisters are a blessing",
  "🍦 Surprise: ice cream date",
  "🤳 Memory: a hundred group selfies",
  "❤️ Quote: love tied in a thread",
  "🍕 Gift: pizza party unlocked",
];

const COLORS = ["#e8a0b8", "#f5c542", "#a855f7", "#ffd27d", "#ff7eb3"];
const EMOJI = ["🎈", "🎀", "🧧", "🎁"];

type Balloon = { id: number; x: number; dur: number; color: string; emoji: string; reveal: string };

export default function BalloonGame() {
  const [playing, setPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [balloons, setBalloons] = useState<Balloon[]>([]);
  const [reveal, setReveal] = useState<string | null>(null);
  const idRef = useRef(0);

  useEffect(() => {
    if (!playing) return;
    const spawn = setInterval(() => {
      const b: Balloon = {
        id: idRef.current++,
        x: 8 + Math.random() * 84,
        dur: 5 + Math.random() * 3,
        color: COLORS[(Math.random() * COLORS.length) | 0],
        emoji: EMOJI[(Math.random() * EMOJI.length) | 0],
        reveal: REVEALS[(Math.random() * REVEALS.length) | 0],
      };
      setBalloons((bs) => [...bs, b]);
    }, 900);
    return () => clearInterval(spawn);
  }, [playing]);

  const pop = (b: Balloon) => {
    setBalloons((bs) => bs.filter((x) => x.id !== b.id));
    setScore((s) => s + 1);
    sfx.pop();
    setReveal(b.reveal);
    if ((score + 1) % 5 === 0) celebrate();
  };

  const reset = () => {
    setScore(0);
    setBalloons([]);
    setReveal(null);
    setPlaying(true);
  };

  return (
    <SectionWrap id="balloons">
      <SectionHeading
        eyebrow="tap, pop, smile"
        title={<>Balloon Pop <span className="gradient-gold-text">Game</span></>}
        subtitle="Pop the floating balloons to reveal little surprises and memories."
      />

      <div className="mx-auto max-w-2xl">
        <div className="mb-4 flex items-center justify-between">
          <span className="glass rounded-full px-4 py-1.5 text-sm text-amber-100">Score: <b className="text-glow-gold">{score}</b></span>
          {!playing ? (
            <button onClick={() => setPlaying(true)} className="btn-gold"><Play className="h-4 w-4" /> Start</button>
          ) : (
            <button onClick={reset} className="btn-ghost"><RotateCcw className="h-4 w-4" /> Reset</button>
          )}
        </div>

        <div className="relative h-80 overflow-hidden rounded-3xl border border-white/10 bg-[radial-gradient(circle_at_50%_120%,rgba(168,85,247,0.25),rgba(4,2,10,0.6))]">
          {!playing && (
            <div className="absolute inset-0 grid place-items-center text-center">
              <div>
                <p className="text-5xl">🎈</p>
                <p className="mt-2 text-amber-100/70">Press Start and tap the balloons!</p>
              </div>
            </div>
          )}

          <AnimatePresence>
            {balloons.map((b) => (
              <motion.button
                key={b.id}
                initial={{ y: 360, opacity: 0 }}
                animate={{ y: -60, opacity: 1 }}
                exit={{ scale: 1.6, opacity: 0 }}
                transition={{ duration: b.dur, ease: "linear" }}
                onClick={() => pop(b)}
                onAnimationComplete={() => setBalloons((bs) => bs.filter((x) => x.id !== b.id))}
                className="absolute bottom-0 flex flex-col items-center"
                style={{ left: `${b.x}%` }}
                aria-label="Pop balloon"
              >
                <span className="text-4xl drop-shadow-[0_0_10px_rgba(0,0,0,0.5)]" style={{ filter: `drop-shadow(0 0 8px ${b.color})` }}>{b.emoji}</span>
                <span className="h-4 w-px bg-white/30" />
              </motion.button>
            ))}
          </AnimatePresence>

          <AnimatePresence>
            {reveal && (
              <motion.div
                key={reveal + score}
                initial={{ opacity: 0, y: 10, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0 }}
                className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full glass-strong px-5 py-2 text-sm text-amber-50"
              >
                {reveal}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </SectionWrap>
  );
}
