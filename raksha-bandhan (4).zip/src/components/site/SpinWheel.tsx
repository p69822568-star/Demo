"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SectionHeading, SectionWrap } from "./Primitives";
import { sfx } from "@/lib/sfx";
import { bigCelebrate } from "@/lib/celebrate";

const SEGMENTS = [
  { label: "Chocolate", emoji: "🍫", color: "#7a4a06" },
  { label: "Gift", emoji: "🎁", color: "#6d28d9" },
  { label: "Shopping", emoji: "🛍️", color: "#d4a017" },
  { label: "Dinner", emoji: "🍽️", color: "#a855f7" },
  { label: "Movie", emoji: "🎬", color: "#92400e" },
  { label: "Selfie", emoji: "🤳", color: "#b8860b" },
  { label: "Surprise", emoji: "✨", color: "#7c3aed" },
  { label: "Lucky Draw", emoji: "🍀", color: "#d4a017" },
];

export default function SpinWheel() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const rotation = useRef(0);

  const draw = (rot: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const size = 300;
    const cx = size / 2;
    const r = size / 2 - 6;
    const n = SEGMENTS.length;
    const arc = (Math.PI * 2) / n;

    ctx.clearRect(0, 0, size, size);
    ctx.save();
    ctx.translate(cx, cx);
    ctx.rotate(rot);

    SEGMENTS.forEach((seg, i) => {
      const a0 = i * arc;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, r, a0, a0 + arc);
      ctx.closePath();
      ctx.fillStyle = seg.color;
      ctx.fill();
      ctx.strokeStyle = "rgba(255,233,168,0.6)";
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.save();
      ctx.rotate(a0 + arc / 2);
      ctx.textAlign = "right";
      ctx.fillStyle = "#fff8ee";
      ctx.font = "600 13px Poppins, sans-serif";
      ctx.fillText(`${seg.emoji} ${seg.label}`, r - 12, 5);
      ctx.restore();
    });
    ctx.restore();

    // hub
    ctx.beginPath();
    ctx.arc(cx, cx, 22, 0, Math.PI * 2);
    ctx.fillStyle = "#ffe9a8";
    ctx.fill();
    ctx.strokeStyle = "#d4a017";
    ctx.stroke();
  };

  const spin = () => {
    if (spinning) return;
    setSpinning(true);
    setResult(null);
    sfx.whoosh();
    const winner = (Math.random() * SEGMENTS.length) | 0;
    const n = SEGMENTS.length;
    const arc = (Math.PI * 2) / n;
    // pointer at top (-90deg). Target so winner segment center aligns with top.
    const target = Math.PI * 2 * 6 + (Math.PI * 1.5 - (winner * arc + arc / 2));
    const start = rotation.current % (Math.PI * 2);
    const end = start + (target - (start % (Math.PI * 2))) + Math.PI * 2 * 6;
    const t0 = performance.now();
    const dur = 4200;

    const animate = (now: number) => {
      const p = Math.min((now - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 4); // ease-out quart
      rotation.current = start + (end - start) * eased;
      draw(rotation.current);
      if (p < 1) {
        requestAnimationFrame(animate);
      } else {
        setSpinning(false);
        setResult(`${SEGMENTS[winner].emoji} ${SEGMENTS[winner].label}!`);
        sfx.win();
        bigCelebrate();
      }
    };
    requestAnimationFrame(animate);
  };

  return (
    <SectionWrap id="wheel">
      <SectionHeading
        eyebrow="test your luck"
        title={<>Spin the <span className="gradient-gold-text">Wheel</span></>}
        subtitle="Give it a spin and let destiny pick your reward."
      />

      <div className="mx-auto flex max-w-md flex-col items-center">
        <div className="relative anim-pulse-glow rounded-full">
          {/* pointer */}
          <div className="absolute left-1/2 top-[-14px] z-10 -translate-x-1/2 border-x-[12px] border-t-[22px] border-x-transparent border-t-amber-300 drop-shadow-[0_0_8px_rgba(245,197,66,0.8)]" />
          <div className="rounded-full border-2 border-amber-300/50 p-1.5 shadow-[0_0_60px_rgba(245,197,66,0.25)]">
            <canvas ref={canvasRef} width={300} height={300} className="h-[260px] w-[260px] sm:h-[300px] sm:w-[300px]" />
          </div>
        </div>

        <button onClick={spin} disabled={spinning} className="btn-gold mt-8 disabled:opacity-60">
          {spinning ? "Spinning…" : "🎡 Spin Now"}
        </button>

        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              className="glass mt-6 rounded-2xl px-6 py-4 text-center"
            >
              <p className="text-xs uppercase tracking-widest text-amber-200/70">You won</p>
              <p className="font-display text-2xl text-glow-gold">{result}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </SectionWrap>
  );
}
