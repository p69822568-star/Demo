"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Pencil, Trash2, X, Loader2, Check, Inbox } from "lucide-react";

export type Field = {
  key: string;
  label: string;
  type?: "text" | "textarea" | "number" | "url";
  required?: boolean;
  placeholder?: string;
  full?: boolean;
};
export type Column = { key: string; label: string; truncate?: boolean };
export type ResourceConfig = {
  resource: string;
  title: string;
  description: string;
  fields: Field[];
  columns: Column[];
  imageKey?: string;
  toggle?: { key: string; label: string };
  emptyText: string;
};

type Row = Record<string, unknown> & { id: string };

export default function ResourceManager({ config }: { config: ResourceConfig }) {
  const { resource, fields, columns, imageKey, toggle } = config;
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Row | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/${resource}`);
      const data = await res.json();
      setRows(data);
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openCreate = () => {
    const blank: Record<string, string> = {};
    fields.forEach((f) => (blank[f.key] = ""));
    setForm(blank);
    setEditing(null);
    setShowForm(true);
  };

  const openEdit = (row: Row) => {
    const filled: Record<string, string> = {};
    fields.forEach((f) => (filled[f.key] = String(row[f.key] ?? "")));
    setForm(filled);
    setEditing(row);
    setShowForm(true);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    // numeric coercion
    const payload: Record<string, unknown> = { ...form };
    fields.forEach((f) => {
      if (f.type === "number") payload[f.key] = Number(form[f.key]) || 0;
    });

    try {
      if (editing) {
        const res = await fetch(`/api/${resource}/${editing.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const updated: Row = await res.json();
        setRows((r) => r.map((x) => (x.id === editing.id ? { ...x, ...updated } : x)));
      } else {
        const res = await fetch(`/api/${resource}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const created: Row = await res.json();
        setRows((r) => [created, ...r]);
      }
      setShowForm(false);
    } catch {
      /* ignore */
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this item permanently?")) return;
    setRows((r) => r.filter((x) => x.id !== id));
    try {
      await fetch(`/api/${resource}/${id}`, { method: "DELETE" });
    } catch {
      load();
    }
  };

  const doToggle = async (row: Row) => {
    const next = !row[toggle!.key];
    setRows((r) => r.map((x) => (x.id === row.id ? { ...x, [toggle!.key]: next } : x)));
    try {
      await fetch(`/api/${resource}/${row.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [toggle!.key]: next }),
      });
    } catch {
      load();
    }
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl text-glow-gold">{config.title}</h1>
          <p className="text-sm text-amber-100/50">{config.description}</p>
        </div>
        <button onClick={openCreate} className="btn-gold text-sm">
          <Plus className="h-4 w-4" /> Add new
        </button>
      </div>

      {/* table */}
      <div className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03]">
        {loading ? (
          <div className="flex items-center justify-center gap-2 py-16 text-amber-200/60">
            <Loader2 className="h-5 w-5 animate-spin" /> Loading…
          </div>
        ) : rows.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-16 text-center text-amber-100/50">
            <Inbox className="h-8 w-8" />
            <p>{config.emptyText}</p>
            <button onClick={openCreate} className="btn-ghost mt-2 text-xs">Create the first one</button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-white/10 text-xs uppercase tracking-wider text-amber-200/50">
                <tr>
                  {imageKey && <th className="px-4 py-3">Image</th>}
                  {columns.map((c) => (
                    <th key={c.key} className="px-4 py-3">{c.label}</th>
                  ))}
                  {toggle && <th className="px-4 py-3">{toggle.label}</th>}
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.id} className="border-b border-white/5 transition hover:bg-white/[0.03]">
                    {imageKey && (
                      <td className="px-4 py-3">
                        {row[imageKey] ? (
                          <img src={String(row[imageKey])} alt="" className="h-12 w-16 rounded-lg object-cover" />
                        ) : (
                          <div className="h-12 w-16 rounded-lg bg-white/5" />
                        )}
                      </td>
                    )}
                    {columns.map((c) => (
                      <td key={c.key} className={`px-4 py-3 text-amber-50/80 ${c.truncate ? "max-w-[220px] truncate" : ""}`}>
                        {String(row[c.key] ?? "—")}
                      </td>
                    ))}
                    {toggle && (
                      <td className="px-4 py-3">
                        <button
                          onClick={() => doToggle(row)}
                          className={`rounded-full px-3 py-1 text-xs font-medium transition ${
                            row[toggle.key] ? "bg-emerald-500/20 text-emerald-300" : "bg-white/5 text-amber-100/40"
                          }`}
                        >
                          {row[toggle.key] ? <span className="flex items-center gap-1"><Check className="h-3 w-3" /> Yes</span> : "No"}
                        </button>
                      </td>
                    )}
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => openEdit(row)} className="rounded-lg bg-white/5 p-2 text-amber-200 hover:bg-white/10" aria-label="Edit">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button onClick={() => remove(row.id)} className="rounded-lg bg-rose-500/10 p-2 text-rose-300 hover:bg-rose-500/20" aria-label="Delete">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* form modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            className="fixed inset-0 z-[200] grid place-items-center bg-black/70 p-4 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowForm(false)}
          >
            <motion.form
              onSubmit={save}
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-strong w-full max-w-lg rounded-2xl p-6"
            >
              <div className="mb-4 flex items-center justify-between">
                <h2 className="font-display text-xl text-glow-gold">{editing ? "Edit" : "Create"} {config.title}</h2>
                <button type="button" onClick={() => setShowForm(false)}><X className="h-5 w-5 text-amber-100/60" /></button>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                {fields.map((f) => (
                  <div key={f.key} className={f.full || f.type === "textarea" ? "sm:col-span-2" : ""}>
                    <label className="mb-1 block text-xs uppercase tracking-wide text-amber-200/60">{f.label}</label>
                    {f.type === "textarea" ? (
                      <textarea
                        value={form[f.key] ?? ""}
                        onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                        rows={3}
                        required={f.required}
                        placeholder={f.placeholder}
                        className="w-full rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm text-amber-50 placeholder:text-white/30 focus:border-amber-300/50 focus:outline-none"
                      />
                    ) : (
                      <input
                        value={form[f.key] ?? ""}
                        onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                        type={f.type === "number" ? "number" : "text"}
                        required={f.required}
                        placeholder={f.placeholder}
                        className="w-full rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm text-amber-50 placeholder:text-white/30 focus:border-amber-300/50 focus:outline-none"
                      />
                    )}
                  </div>
                ))}
              </div>

              <div className="mt-5 flex justify-end gap-2">
                <button type="button" onClick={() => setShowForm(false)} className="btn-ghost text-sm">Cancel</button>
                <button type="submit" disabled={saving} className="btn-gold text-sm disabled:opacity-60">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                  {editing ? "Save changes" : "Create"}
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
