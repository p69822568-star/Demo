"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  MessageSquareHeart,
  Quote as QuoteIcon,
  Milestone,
  Images,
  LogOut,
  Home,
  Menu,
  X,
} from "lucide-react";

const LINKS = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/dashboard/wishes", label: "Memory Wall", icon: MessageSquareHeart },
  { href: "/dashboard/quotes", label: "Quotes", icon: QuoteIcon },
  { href: "/dashboard/timeline", label: "Timeline", icon: Milestone },
  { href: "/dashboard/photos", label: "Photos", icon: Images },
];

export default function Sidebar({ user }: { user: { name: string; email: string } }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  };

  return (
    <>
      {/* mobile top bar */}
      <div className="fixed inset-x-0 top-0 z-40 flex items-center justify-between border-b border-white/10 bg-[#07071c]/80 px-4 py-3 backdrop-blur md:hidden">
        <span className="font-script text-2xl text-rose-200">Rakhi Bond</span>
        <button onClick={() => setOpen(true)} aria-label="Open menu"><Menu className="h-6 w-6 text-amber-100" /></button>
      </div>

      {/* sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-white/10 bg-[#0a0820]/90 backdrop-blur-xl transition-transform md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-5">
          <span className="font-script text-2xl text-rose-200">Rakhi Bond</span>
          <button onClick={() => setOpen(false)} className="md:hidden" aria-label="Close menu"><X className="h-5 w-5 text-amber-100" /></button>
        </div>

        <nav className="flex-1 space-y-1 px-3">
          {LINKS.map((l) => {
            const active = pathname === l.href;
            const Icon = l.icon;
            return (
              <Link
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${
                  active ? "bg-amber-300/15 text-amber-200" : "text-amber-100/60 hover:bg-white/5 hover:text-amber-100"
                }`}
              >
                <Icon className="h-4 w-4" />
                {l.label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-white/10 p-4">
          <div className="mb-3 rounded-xl bg-white/5 p-3">
            <p className="truncate text-sm font-medium text-amber-100">{user.name}</p>
            <p className="truncate text-xs text-amber-100/40">{user.email}</p>
          </div>
          <div className="flex gap-2">
            <Link href="/" className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-white/10 px-3 py-2 text-xs text-amber-100/70 hover:bg-white/5">
              <Home className="h-3.5 w-3.5" /> Site
            </Link>
            <button onClick={logout} className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-300 hover:bg-rose-500/20">
              <LogOut className="h-3.5 w-3.5" /> Logout
            </button>
          </div>
        </div>
      </aside>

      {open && <div onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-black/60 md:hidden" />}
    </>
  );
}
