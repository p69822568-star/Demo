/**
 * Seed script — run with:  npx tsx src/db/seed.ts
 * Creates the owner account + rich demo content so the app feels alive.
 */
import "dotenv/config";
import { db } from "./index";
import {
  users,
  quotes,
  timelineEvents,
  photos,
  wishes,
} from "./schema";
import { hashPassword } from "../lib/auth";
import {
  SEED_QUOTES,
  SEED_TIMELINE,
  SEED_PHOTOS,
  SEED_WISHES,
} from "../lib/seed-data";

async function seed() {
  console.log("🌱 Seeding database…");

  // 1. Owner account (idempotent)
  const email = "akash@rakhi.love";
  const existing = await db.select().from(users).limit(1);
  if (existing.length === 0) {
    const passwordHash = await hashPassword("rakhi2026");
    await db.insert(users).values({
      name: "Akash Bhai & Banti Bhai",
      email,
      passwordHash,
      role: "owner",
    });
    console.log(`  ✓ Owner created — login: ${email} / rakhi2026`);
  } else {
    console.log("  • Owner already exists, skipping.");
  }

  // 2. Content (only when empty)
  if ((await db.select().from(quotes).limit(1)).length === 0) {
    await db.insert(quotes).values(SEED_QUOTES as any);
    console.log(`  ✓ Inserted ${SEED_QUOTES.length} quotes`);
  }
  if ((await db.select().from(timelineEvents).limit(1)).length === 0) {
    await db
      .insert(timelineEvents)
      .values(
        SEED_TIMELINE.map((t, i) => ({ ...t, position: i })) as any
      );
    console.log(`  ✓ Inserted ${SEED_TIMELINE.length} timeline events`);
  }
  if ((await db.select().from(photos).limit(1)).length === 0) {
    await db
      .insert(photos)
      .values(
        SEED_PHOTOS.map((p, i) => ({ ...p, position: i })) as any
      );
    console.log(`  ✓ Inserted ${SEED_PHOTOS.length} photos`);
  }
  if ((await db.select().from(wishes).limit(1)).length === 0) {
    await db.insert(wishes).values(SEED_WISHES as any);
    console.log(`  ✓ Inserted ${SEED_WISHES.length} wishes`);
  }

  console.log("✅ Seeding complete.");
  process.exit(0);
}

seed().catch((err) => {
  console.error("❌ Seed failed:", err);
  process.exit(1);
});
