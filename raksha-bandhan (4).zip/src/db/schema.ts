import {
  pgTable,
  text,
  timestamp,
  integer,
  boolean,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/*  AUTH — dashboard users                                             */
/* ------------------------------------------------------------------ */
export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 180 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 20 }).default("owner").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------------------ */
/*  MEMORY WALL — visitor wishes (sticky notes)                        */
/* ------------------------------------------------------------------ */
export const wishes = pgTable("wishes", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  message: text("message").notNull(),
  color: varchar("color", { length: 40 }).default("rose").notNull(),
  hearts: integer("hearts").default(0).notNull(),
  approved: boolean("approved").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------------------ */
/*  PHOTO GALLERY — personal memories                                  */
/* ------------------------------------------------------------------ */
export const photos = pgTable("photos", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 160 }).notNull(),
  caption: text("caption").notNull(),
  src: text("src").notNull(),
  category: varchar("category", { length: 60 }).default("memories").notNull(),
  position: integer("position").default(0).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------------------ */
/*  QUOTES — rotating memory quotes                                    */
/* ------------------------------------------------------------------ */
export const quotes = pgTable("quotes", {
  id: uuid("id").defaultRandom().primaryKey(),
  text: text("text").notNull(),
  author: varchar("author", { length: 120 }).default("Anonymous"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------------------ */
/*  TIMELINE — our journey events                                      */
/* ------------------------------------------------------------------ */
export const timelineEvents = pgTable("timeline_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  year: varchar("year", { length: 40 }).notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 60 }).default("✨"),
  position: integer("position").default(0).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------------------ */
/*  GAME SCORES — quiz & mini-games leaderboard                        */
/* ------------------------------------------------------------------ */
export const scores = pgTable("scores", {
  id: uuid("id").defaultRandom().primaryKey(),
  player: varchar("player", { length: 120 }).notNull(),
  game: varchar("game", { length: 60 }).notNull(),
  score: integer("score").default(0).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});
