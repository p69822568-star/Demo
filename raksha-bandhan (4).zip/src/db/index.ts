import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Database connection.
 *
 * NOTE: We intentionally do NOT throw when DATABASE_URL is missing.
 * During `next build` (e.g. on Vercel) the route modules are imported for
 * page-data collection before runtime env vars are guaranteed, and an eager
 * throw would fail the whole build. The Pool is constructed lazily-safe;
 * actual queries only run at request time, where DATABASE_URL is present.
 */
const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

const connectionString = process.env.DATABASE_URL || undefined;

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString,
    // pg tolerates an undefined connection string at construction time;
    // it only attempts to connect when a query is actually executed.
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
