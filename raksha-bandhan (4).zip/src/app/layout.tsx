import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Playfair_Display, Poppins, Great_Vibes } from "next/font/google";
import "./globals.css";

const playfair = Playfair_Display({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-playfair",
  weight: ["400", "600", "700", "800", "900"],
});

const poppins = Poppins({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-poppins",
  weight: ["300", "400", "500", "600", "700"],
});

const vibes = Great_Vibes({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-vibes",
  weight: ["400"],
});

export const metadata: Metadata = {
  title: "Raksha Bandhan — A Bond Beyond Words",
  description:
    "A cinematic, emotional gift dedicated by Akash Bhai & Banti Bhai to their beloved sisters Lucky Di, Vicky Di, Sapna, Neha & Kalpan.",
  keywords: [
    "Raksha Bandhan", "Rakhi", "sisters", "brothers", "bond", "love",
    "Akash", "Banti", "memories", "gift",
  ],
  authors: [{ name: "Akash Bhai & Banti Bhai" }],
  openGraph: {
    title: "Raksha Bandhan — A Bond Beyond Words",
    description: "A Bond of Love, Protection, Memories and Forever.",
    type: "website",
  },
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: "#04020a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${playfair.variable} ${poppins.variable} ${vibes.variable}`}>
      <body className="antialiased">{children}</body>
    </html>
  );
}
