import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { createSession } from "@/lib/session";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  const { name, email, password } = await req.json().catch(() => ({}));
  const n = (name ?? "").toString().trim();
  const e = (email ?? "").toString().trim().toLowerCase();
  const p = (password ?? "").toString();

  if (!n || !e || p.length < 6) {
    return NextResponse.json({ error: "Provide name, email and a 6+ char password" }, { status: 422 });
  }

  const exists = await db.select().from(users).where(eq(users.email, e)).limit(1);
  if (exists.length > 0) {
    return NextResponse.json({ error: "An account with this email already exists" }, { status: 409 });
  }

  const passwordHash = await hashPassword(p);
  const [user] = await db
    .insert(users)
    .values({ name: n, email: e, passwordHash })
    .returning({ id: users.id, name: users.name, email: users.email });

  await createSession({ userId: String(user.id), email: user.email, name: user.name });
  return NextResponse.json({ user });
}
