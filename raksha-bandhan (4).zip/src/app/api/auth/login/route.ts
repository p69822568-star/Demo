import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { verifyPassword } from "@/lib/auth";
import { createSession } from "@/lib/session";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  const { email, password } = await req.json().catch(() => ({}));
  const e = (email ?? "").toString().trim().toLowerCase();

  if (!e || !password) {
    return NextResponse.json({ error: "Email and password are required" }, { status: 422 });
  }

  const [user] = await db.select().from(users).where(eq(users.email, e)).limit(1);
  if (!user) {
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) {
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  await createSession({ userId: String(user.id), email: user.email, name: user.name });
  return NextResponse.json({ user: { id: String(user.id), name: user.name, email: user.email } });
}
