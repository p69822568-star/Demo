import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { wishes } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET approved wishes, newest first. */
export async function GET() {
  const rows = await db
    .select()
    .from(wishes)
    .where(eq(wishes.approved, true))
    .orderBy(desc(wishes.createdAt))
    .limit(80);

  return NextResponse.json(
    rows.map((r) => ({
      id: String(r.id),
      name: r.name,
      message: r.message,
      color: r.color,
      hearts: r.hearts,
    }))
  );
}

/** POST a new wish from a visitor. */
export async function POST(req: NextRequest) {
  let body: { name?: string; message?: string; color?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const name = (body.name ?? "").trim().slice(0, 120);
  const message = (body.message ?? "").trim().slice(0, 220);
  const color = (body.color ?? "rose").trim().slice(0, 40);

  if (!name || !message) {
    return NextResponse.json({ error: "Name and message are required" }, { status: 422 });
  }

  const [created] = await db
    .insert(wishes)
    .values({ name, message, color })
    .returning();

  return NextResponse.json({
    id: String(created.id),
    name: created.name,
    message: created.message,
    color: created.color,
    hearts: created.hearts,
  });
}
