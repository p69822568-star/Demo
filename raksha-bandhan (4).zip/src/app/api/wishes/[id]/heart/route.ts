import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { wishes } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Increment hearts on a wish. */
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [updated] = await db
    .update(wishes)
    .set({ hearts: sql`${wishes.hearts} + 1` })
    .where(eq(wishes.id, id))
    .returning({ hearts: wishes.hearts });

  if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ hearts: updated.hearts });
}
