import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { wishes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/guard";

export const dynamic = "force-dynamic";

/** Delete a wish (protected). */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  await db.delete(wishes).where(eq(wishes.id, id));
  return NextResponse.json({ ok: true });
}

/** Edit a wish (protected). */
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  const { name, message, color } = await req.json().catch(() => ({}));
  const [updated] = await db
    .update(wishes)
    .set({
      name: (name ?? "").toString().slice(0, 120),
      message: (message ?? "").toString().slice(0, 220),
      color: (color ?? "rose").toString().slice(0, 40),
    })
    .where(eq(wishes.id, id))
    .returning();
  if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({
    id: String(updated.id),
    name: updated.name,
    message: updated.message,
    color: updated.color,
    hearts: updated.hearts,
  });
}

/** Toggle approval of a wish (protected). */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  const { approved } = await req.json().catch(() => ({}));
  const [updated] = await db
    .update(wishes)
    .set({ approved: !!approved })
    .where(eq(wishes.id, id))
    .returning();

  if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ ok: true, approved: updated.approved });
}
