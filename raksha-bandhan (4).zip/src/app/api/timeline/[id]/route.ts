import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { timelineEvents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/guard";

export const dynamic = "force-dynamic";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  const { year, title, description, icon, position } = await req.json().catch(() => ({}));
  const [updated] = await db
    .update(timelineEvents)
    .set({
      year: (year ?? "").toString().slice(0, 40),
      title: (title ?? "").toString().slice(0, 160),
      description: (description ?? "").toString(),
      icon: (icon ?? "✨").toString().slice(0, 60),
      position: Number(position) || 0,
    })
    .where(eq(timelineEvents.id, id))
    .returning();
  if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({
    id: String(updated.id),
    year: updated.year,
    title: updated.title,
    description: updated.description,
    icon: updated.icon,
    position: updated.position,
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  await db.delete(timelineEvents).where(eq(timelineEvents.id, id));
  return NextResponse.json({ ok: true });
}
