import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { timelineEvents } from "@/db/schema";
import { asc } from "drizzle-orm";
import { requireUser } from "@/lib/guard";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(timelineEvents).orderBy(asc(timelineEvents.position));
  return NextResponse.json(
    rows.map((r) => ({
      id: String(r.id),
      year: r.year,
      title: r.title,
      description: r.description,
      icon: r.icon,
      position: r.position,
    }))
  );
}

export async function POST(req: NextRequest) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { year, title, description, icon, position } = await req.json().catch(() => ({}));
  const t = (title ?? "").toString().trim();
  if (!t) return NextResponse.json({ error: "Title required" }, { status: 422 });

  const [created] = await db
    .insert(timelineEvents)
    .values({
      year: (year ?? "").toString().slice(0, 40),
      title: t.slice(0, 160),
      description: (description ?? "").toString(),
      icon: (icon ?? "✨").toString().slice(0, 60),
      position: Number(position) || 0,
    })
    .returning();
  return NextResponse.json({
    id: String(created.id),
    year: created.year,
    title: created.title,
    description: created.description,
    icon: created.icon,
    position: created.position,
  });
}
