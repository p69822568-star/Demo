import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { photos } from "@/db/schema";
import { asc } from "drizzle-orm";
import { requireUser } from "@/lib/guard";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(photos).orderBy(asc(photos.position));
  return NextResponse.json(
    rows.map((r) => ({
      id: String(r.id),
      title: r.title,
      caption: r.caption,
      src: r.src,
      category: r.category,
      position: r.position,
    }))
  );
}

export async function POST(req: NextRequest) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { title, caption, src, category, position } = await req.json().catch(() => ({}));
  const s = (src ?? "").toString().trim();
  const t = (title ?? "").toString().trim();
  if (!s || !t) return NextResponse.json({ error: "Title and image URL required" }, { status: 422 });

  const [created] = await db
    .insert(photos)
    .values({
      title: t.slice(0, 160),
      caption: (caption ?? "").toString(),
      src: s,
      category: (category ?? "memories").toString().slice(0, 60),
      position: Number(position) || 0,
    })
    .returning();
  return NextResponse.json({
    id: String(created.id),
    title: created.title,
    caption: created.caption,
    src: created.src,
    category: created.category,
    position: created.position,
  });
}
