import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { photos } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/guard";

export const dynamic = "force-dynamic";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  const { title, caption, src, category, position } = await req.json().catch(() => ({}));
  const [updated] = await db
    .update(photos)
    .set({
      title: (title ?? "").toString().slice(0, 160),
      caption: (caption ?? "").toString(),
      src: (src ?? "").toString(),
      category: (category ?? "memories").toString().slice(0, 60),
      position: Number(position) || 0,
    })
    .where(eq(photos.id, id))
    .returning();
  if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({
    id: String(updated.id),
    title: updated.title,
    caption: updated.caption,
    src: updated.src,
    category: updated.category,
    position: updated.position,
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  await db.delete(photos).where(eq(photos.id, id));
  return NextResponse.json({ ok: true });
}
