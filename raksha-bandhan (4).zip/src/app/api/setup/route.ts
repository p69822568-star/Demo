import { NextResponse } from "next/server";
import { pool } from "@/db";
import { db } from "@/db";
import { users, quotes, timelineEvents, photos, wishes } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { SEED_QUOTES, SEED_TIMELINE, SEED_PHOTOS, SEED_WISHES } from "@/lib/seed-data";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * One-click setup for fresh deployments.
 * Creates all tables (if missing) and seeds demo content + the owner account.
 * Visit this route ONCE after deploying:  https://your-app.vercel.app/api/setup
 * Safe to call repeatedly (fully idempotent).
 */
export async function GET() {
  const log: string[] = [];

  try {
    // 1. Create extension + tables (raw SQL, idempotent)
    await pool.query(`CREATE EXTENSION IF NOT EXISTS "pgcrypto";`);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS "users" (
        "id" uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        "name" varchar(120) NOT NULL,
        "email" varchar(180) NOT NULL UNIQUE,
        "password_hash" text NOT NULL,
        "role" varchar(20) NOT NULL DEFAULT 'owner',
        "created_at" timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS "wishes" (
        "id" uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        "name" varchar(120) NOT NULL,
        "message" text NOT NULL,
        "color" varchar(40) NOT NULL DEFAULT 'rose',
        "hearts" integer NOT NULL DEFAULT 0,
        "approved" boolean NOT NULL DEFAULT true,
        "created_at" timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS "photos" (
        "id" uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        "title" varchar(160) NOT NULL,
        "caption" text NOT NULL,
        "src" text NOT NULL,
        "category" varchar(60) NOT NULL DEFAULT 'memories',
        "position" integer NOT NULL DEFAULT 0,
        "created_at" timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS "quotes" (
        "id" uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        "text" text NOT NULL,
        "author" varchar(120) DEFAULT 'Anonymous',
        "created_at" timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS "timeline_events" (
        "id" uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        "year" varchar(40) NOT NULL,
        "title" varchar(160) NOT NULL,
        "description" text NOT NULL,
        "icon" varchar(60) DEFAULT '✨',
        "position" integer NOT NULL DEFAULT 0,
        "created_at" timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS "scores" (
        "id" uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        "player" varchar(120) NOT NULL,
        "game" varchar(60) NOT NULL,
        "score" integer NOT NULL DEFAULT 0,
        "created_at" timestamptz NOT NULL DEFAULT now()
      );
    `);
    log.push("✓ Tables ready");

    // 2. Seed owner account (only if no users exist)
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length === 0) {
      const passwordHash = await hashPassword("rakhi2026");
      await db.insert(users).values({
        name: "Akash Bhai & Banti Bhai",
        email: "akash@rakhi.love",
        passwordHash,
        role: "owner",
      });
      log.push("✓ Owner created (akash@rakhi.love / rakhi2026)");
    } else {
      log.push("• Owner already exists");
    }

    // 3. Seed content (only when empty)
    if ((await db.select().from(quotes).limit(1)).length === 0) {
      await db.insert(quotes).values(SEED_QUOTES as any);
      log.push(`✓ ${SEED_QUOTES.length} quotes inserted`);
    }
    if ((await db.select().from(timelineEvents).limit(1)).length === 0) {
      await db.insert(timelineEvents).values(SEED_TIMELINE.map((t, i) => ({ ...t, position: i })) as any);
      log.push(`✓ ${SEED_TIMELINE.length} timeline events inserted`);
    }
    if ((await db.select().from(photos).limit(1)).length === 0) {
      await db.insert(photos).values(SEED_PHOTOS.map((p, i) => ({ ...p, position: i })) as any);
      log.push(`✓ ${SEED_PHOTOS.length} photos inserted`);
    }
    if ((await db.select().from(wishes).limit(1)).length === 0) {
      await db.insert(wishes).values(SEED_WISHES as any);
      log.push(`✓ ${SEED_WISHES.length} wishes inserted`);
    }

    return NextResponse.json({
      ok: true,
      message: "Setup complete! Your site is ready. You can now log in.",
      steps: log,
      login: { email: "akash@rakhi.love", password: "rakhi2026" },
    });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "Setup failed", steps: log },
      { status: 500 }
    );
  }
}
