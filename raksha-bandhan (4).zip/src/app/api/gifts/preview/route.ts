import { NextRequest, NextResponse } from "next/server";

/**
 * Admin preview unlock for the Gift Corner.
 * Password is checked SERVER-SIDE so it never leaks into the browser bundle.
 * Override in production with the GIFT_PREVIEW_PASSWORD env var.
 */
const CORRECT = process.env.GIFT_PREVIEW_PASSWORD ?? "adarsh@#512";

export async function POST(req: NextRequest) {
  const { password } = await req.json().catch(() => ({ password: "" }));
  if (typeof password === "string" && password === CORRECT) {
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ ok: false, error: "Wrong password" }, { status: 401 });
}
