import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { quotes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/guard";

export const dynamic = "force-dynamic";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  const { text, author } = await req.json().catch(() => ({}));
  const [updated] = await db
    .update(quotes)
    .set({
      text: (text ?? "").toString().slice(0, 500),
      author: (author ?? "").toString().slice(0, 120) || null,
    })
    .where(eq(quotes.id, id))
    .returning();
  if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ id: String(updated.id), text: updated.text, author: updated.author });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { id } = await params;
  await db.delete(quotes).where(eq(quotes.id, id));
  return NextResponse.json({ ok: true });
}
