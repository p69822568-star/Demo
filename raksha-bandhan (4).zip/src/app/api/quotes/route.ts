import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { quotes } from "@/db/schema";
import { desc } from "drizzle-orm";
import { requireUser } from "@/lib/guard";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(quotes).orderBy(desc(quotes.createdAt));
  return NextResponse.json(rows.map((r) => ({ id: String(r.id), text: r.text, author: r.author })));
}

export async function POST(req: NextRequest) {
  const guard = await requireUser();
  if (guard.response) return guard.response;

  const { text, author } = await req.json().catch(() => ({}));
  const t = (text ?? "").toString().trim();
  if (!t) return NextResponse.json({ error: "Text required" }, { status: 422 });

  const [created] = await db
    .insert(quotes)
    .values({ text: t.slice(0, 500), author: (author ?? "").toString().slice(0, 120) || null })
    .returning();
  return NextResponse.json({ id: String(created.id), text: created.text, author: created.author });
}
