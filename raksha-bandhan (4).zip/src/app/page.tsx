import { nextRakshaBandhan, giftUnlockTime } from "@/lib/constants";
import { SEED_PHOTOS, SEED_QUOTES, SEED_TIMELINE } from "@/lib/seed-data";
import Experience from "@/components/site/Experience";
import type { Photo } from "@/components/site/Gallery";
import type { Quote } from "@/components/site/Quotes";
import type { TimelineEvent } from "@/components/site/JourneyTimeline";

export const dynamic = "force-dynamic";

/** Bundled demo content used as the zero-config fallback. */
function seedContent() {
  return {
    photos: SEED_PHOTOS.map((p, i) => ({ id: `s${i}`, ...p })) as Photo[],
    quotes: SEED_QUOTES.map((q, i) => ({ id: `s${i}`, text: q.text, author: q.author ?? null })) as Quote[],
    timeline: SEED_TIMELINE.map((t, i) => ({ id: `s${i}`, ...t })) as TimelineEvent[],
  };
}

export default async function Home() {
  let content = seedContent();

  // Only talk to the database when a connection string is configured.
  // With NO DATABASE_URL the public site runs entirely on bundled content —
  // fully zero-config and crash-free on Vercel.
  if (process.env.DATABASE_URL) {
    try {
      const { db } = await import("@/db");
      const { photos: photosTable, quotes: quotesTable, timelineEvents } = await import("@/db/schema");
      const [p, q, t] = await Promise.all([
        db.select().from(photosTable).orderBy(photosTable.position),
        db.select().from(quotesTable),
        db.select().from(timelineEvents).orderBy(timelineEvents.position),
      ]);
      const photos = p.map((row) => ({
        id: String(row.id), title: row.title, caption: row.caption, src: row.src, category: row.category,
      }));
      const quotes = q.map((row) => ({ id: String(row.id), text: row.text, author: row.author ?? null }));
      const timeline = t.map((row) => ({
        id: String(row.id), year: row.year, title: row.title, description: row.description, icon: row.icon ?? "✨",
      }));
      if (photos.length) content = { photos, quotes, timeline };
    } catch {
      // DB not reachable — silently fall back to bundled content
    }
  }

  const target = nextRakshaBandhan().getTime();
  const giftUnlock = giftUnlockTime();

  return (
    <Experience
      photos={content.photos}
      quotes={content.quotes}
      timeline={content.timeline}
      target={target}
      giftUnlock={giftUnlock}
    />
  );
}
