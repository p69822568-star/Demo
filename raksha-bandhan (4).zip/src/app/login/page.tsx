"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mode === "login" ? { email, password } : { name, email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Something went wrong");
      router.push("/dashboard");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4">
      <div className="pointer-events-none absolute h-[60vmin] w-[60vmin] rounded-full bg-[radial-gradient(circle,rgba(245,197,66,0.18),transparent_60%)] blur-3xl" />

      <div className="glass-strong relative w-full max-w-md rounded-3xl p-8">
        <div className="mb-6 text-center">
          <p className="font-script text-3xl text-rose-200">Rakhi Bond</p>
          <h1 className="font-display mt-1 text-2xl text-glow-gold">
            {mode === "login" ? "Welcome back" : "Create account"}
          </h1>
          <p className="mt-1 text-xs text-amber-100/50">Manage your Raksha Bandhan experience</p>
        </div>

        <div className="mb-6 grid grid-cols-2 gap-1 rounded-full bg-white/5 p-1 text-sm">
          {(["login", "register"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`rounded-full py-2 font-medium capitalize transition ${mode === m ? "bg-amber-300 text-black" : "text-amber-100/70"}`}
            >
              {m}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="space-y-3">
          {mode === "register" && (
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="auth-input" />
          )}
          <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="Email" className="auth-input" />
          <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="Password (min 6 chars)" className="auth-input" />

          {error && <p className="rounded-lg bg-rose-500/15 px-3 py-2 text-sm text-rose-300">{error}</p>}

          <button disabled={loading} className="btn-gold w-full disabled:opacity-60">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>

        <p className="mt-5 rounded-xl bg-amber-300/10 px-3 py-2 text-center text-xs text-amber-200/70">
          Demo owner — <b>akash@rakhi.love</b> / <b>rakhi2026</b>
        </p>

        <a href="/" className="mt-4 block text-center text-xs text-amber-100/50 hover:text-amber-100">← Back to the experience</a>
      </div>

      <style jsx>{`
        :global(.auth-input) {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgba(255,255,255,0.1);
          background: rgba(0,0,0,0.3);
          padding: 0.75rem 1rem;
          color: #fff8ee;
          outline: none;
        }
        :global(.auth-input:focus) { border-color: rgba(245,197,66,0.5); }
        :global(.auth-input::placeholder) { color: rgba(255,255,255,0.3); }
      `}</style>
    </div>
  );
}
