import ResourceManager from "@/components/dashboard/ResourceManager";
import type { ResourceConfig } from "@/components/dashboard/ResourceManager";

export const dynamic = "force-dynamic";

const config: ResourceConfig = {
  resource: "quotes",
  title: "Quotes",
  description: "The rotating memory quotes shown across the experience.",
  fields: [
    { key: "text", label: "Quote", type: "textarea", full: true, required: true },
    { key: "author", label: "Author", placeholder: "optional" },
  ],
  columns: [
    { key: "text", label: "Text", truncate: true },
    { key: "author", label: "Author" },
  ],
  emptyText: "No quotes yet. Add a few heartfelt lines.",
};

export default function QuotesPage() {
  return <ResourceManager config={config} />;
}
