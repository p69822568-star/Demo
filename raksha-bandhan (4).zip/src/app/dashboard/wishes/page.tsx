import ResourceManager from "@/components/dashboard/ResourceManager";
import type { ResourceConfig } from "@/components/dashboard/ResourceManager";

export const dynamic = "force-dynamic";

const config: ResourceConfig = {
  resource: "wishes",
  title: "Memory Wall",
  description: "Approve, edit or remove wishes left by visitors on the site.",
  fields: [
    { key: "name", label: "Name", required: true },
    { key: "message", label: "Message", type: "textarea", full: true, required: true },
    { key: "color", label: "Color", placeholder: "rose · amber · violet · emerald" },
  ],
  columns: [
    { key: "name", label: "Name" },
    { key: "message", label: "Message", truncate: true },
    { key: "color", label: "Color" },
    { key: "hearts", label: "Hearts" },
  ],
  toggle: { key: "approved", label: "Visible" },
  emptyText: "No wishes yet. They'll appear here as visitors post them.",
};

export default function WishesPage() {
  return <ResourceManager config={config} />;
}
