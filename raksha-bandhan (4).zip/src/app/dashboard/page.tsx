import { db } from "@/db";
import { wishes, quotes, timelineEvents, photos } from "@/db/schema";
import { desc } from "drizzle-orm";
import { getSession } from "@/lib/session";
import Link from "next/link";
import { MessageSquareHeart, Quote as QuoteIcon, Milestone, Images, ArrowRight } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function Overview() {
  const session = await getSession();

  const [w, q, t, p] = await Promise.all([
    db.select().from(wishes),
    db.select().from(quotes),
    db.select().from(timelineEvents),
    db.select().from(photos),
  ]);

  const recent = [...w].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()).slice(0, 5);

  const stats = [
    { label: "Wishes", value: w.length, icon: MessageSquareHeart, href: "/dashboard/wishes", color: "from-rose-500/30 to-pink-700/20" },
    { label: "Quotes", value: q.length, icon: QuoteIcon, href: "/dashboard/quotes", color: "from-amber-500/30 to-orange-700/20" },
    { label: "Timeline Events", value: t.length, icon: Milestone, href: "/dashboard/timeline", color: "from-violet-500/30 to-purple-700/20" },
    { label: "Photos", value: p.length, icon: Images, href: "/dashboard/photos", color: "from-emerald-500/30 to-teal-700/20" },
  ];

  return (
    <div>
      <div className="mb-8">
        <p className="font-script text-2xl text-rose-200">Namaste 🙏</p>
        <h1 className="font-display text-3xl text-glow-gold md:text-4xl">Welcome, {session?.name?.split(" ")[0]}</h1>
        <p className="mt-1 text-sm text-amber-100/50">Here&apos;s how your Raksha Bandhan experience is doing.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Link
              key={s.label}
              href={s.href}
              className={`glass-card rounded-2xl bg-gradient-to-br ${s.color} p-5`}
            >
              <Icon className="h-6 w-6 text-amber-200" />
              <p className="font-display mt-3 text-4xl font-black text-white">{s.value}</p>
              <p className="text-xs text-amber-100/60">{s.label}</p>
            </Link>
          );
        })}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="glass-card rounded-2xl p-6 lg:col-span-2">
          <h2 className="font-display mb-4 text-xl text-amber-100">Recent wishes</h2>
          <div className="space-y-3">
            {recent.length === 0 && <p className="text-sm text-amber-100/40">No wishes yet.</p>}
            {recent.map((wish) => (
              <div key={wish.id} className="rounded-xl border border-white/5 bg-white/[0.03] p-4">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-amber-100">{wish.name}</span>
                  {!wish.approved && <span className="rounded-full bg-rose-500/20 px-2 py-0.5 text-[10px] text-rose-300">Hidden</span>}
                </div>
                <p className="mt-1 text-sm text-amber-100/70">{wish.message}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card rounded-2xl p-6">
          <h2 className="font-display mb-4 text-xl text-amber-100">Quick actions</h2>
          <div className="space-y-2">
            {[
              ["/dashboard/wishes", "Moderate memory wall"],
              ["/dashboard/quotes", "Add a memory quote"],
              ["/dashboard/photos", "Upload a memory photo"],
              ["/dashboard/timeline", "Edit our journey"],
            ].map(([href, label]) => (
              <Link key={href} href={href} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-amber-100/80 transition hover:border-amber-300/40 hover:bg-amber-300/10">
                {label} <ArrowRight className="h-4 w-4" />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
