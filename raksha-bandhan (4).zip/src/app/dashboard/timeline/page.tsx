import ResourceManager from "@/components/dashboard/ResourceManager";
import type { ResourceConfig } from "@/components/dashboard/ResourceManager";

export const dynamic = "force-dynamic";

const config: ResourceConfig = {
  resource: "timeline",
  title: "Our Journey",
  description: "Timeline events shown in the animated 'Our Journey' section.",
  fields: [
    { key: "year", label: "Year / Era", required: true },
    { key: "title", label: "Title", required: true },
    { key: "description", label: "Description", type: "textarea", full: true },
    { key: "icon", label: "Icon (emoji)", placeholder: "✨" },
    { key: "position", label: "Order", type: "number" },
  ],
  columns: [
    { key: "year", label: "Year" },
    { key: "title", label: "Title" },
    { key: "description", label: "Description", truncate: true },
  ],
  emptyText: "No timeline events yet.",
};

export default function TimelinePage() {
  return <ResourceManager config={config} />;
}
