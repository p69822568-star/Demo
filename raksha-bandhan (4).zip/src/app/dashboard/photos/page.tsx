import ResourceManager from "@/components/dashboard/ResourceManager";
import type { ResourceConfig } from "@/components/dashboard/ResourceManager";

export const dynamic = "force-dynamic";

const config: ResourceConfig = {
  resource: "photos",
  title: "Photos",
  description: "The glowing photo gallery & slideshow. Paste any image URL.",
  fields: [
    { key: "title", label: "Title", required: true },
    { key: "caption", label: "Caption", type: "textarea", full: true },
    { key: "src", label: "Image URL", type: "url", full: true, required: true, placeholder: "https://…" },
    { key: "category", label: "Category", placeholder: "Family · Memories · Festivals" },
    { key: "position", label: "Order", type: "number" },
  ],
  columns: [
    { key: "title", label: "Title" },
    { key: "category", label: "Category" },
    { key: "caption", label: "Caption", truncate: true },
  ],
  imageKey: "src",
  emptyText: "No photos yet. Add your personal memories.",
};

export default function PhotosPage() {
  return <ResourceManager config={config} />;
}
