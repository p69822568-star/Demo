# ✨ Raksha Bandhan — A Bond Beyond Words

A cinematic, emotional, full-stack gift website by **Akash Bhai & Banti Bhai**, dedicated to **Lucky Di ❤️ Vicky Di ❤️ Sapna ❤️ Neha ❤️ Kalpan**.

Built with **Next.js (App Router) · PostgreSQL · Drizzle ORM · Framer Motion · Tailwind CSS**.

---

## 🚀 Deploy in 4 steps (free + always online)

### 1. Create a free database (Neon)
1. Go to https://neon.tech → Sign up (free)
2. **Create New Project**
3. Copy the **connection string** (looks like `postgresql://...?sslmode=require`)
4. Save it — this is your `DATABASE_URL`

### 2. Push this code to GitHub
1. Create a new repository on https://github.com
2. Upload all files from this folder (or use GitHub Desktop / `git push`)

### 3. Deploy on Vercel
1. Go to https://vercel.com → **Sign Up → Continue with GitHub**
2. **Add New → Project → Import** your repository
3. Open **Environment Variables** and add:

   | Name | Value |
   |------|-------|
   | `DATABASE_URL` | your Neon connection string |
   | `AUTH_SECRET` | any random text, e.g. `rakhi-secret-2026` |

4. Click **Deploy** ⏳

### 4. One-click database setup
After deploy, open this URL **once** in your browser:
```
https://YOUR-APP.vercel.app/api/setup
```
You'll see `{"ok":true,...}` → database + owner account are ready. 🎉

---

## 🔑 Login (Dashboard)
- URL: `https://YOUR-APP.vercel.app/login`
- Email: `akash@rakhi.love`
- Password: `rakhi2026`

From the dashboard you can manage **Wishes, Quotes, Timeline & Photos** (full CRUD).

---

## 💻 Run locally
```bash
npm install
cp .env.example .env      # then fill in your DATABASE_URL + AUTH_SECRET
npm run dev               # http://localhost:3000
```
Then visit `http://localhost:3000/api/setup` once to create tables + seed data.

---

## 🎨 Customize
- **Photos**: Dashboard → Photos, or edit `src/lib/constants.ts` → `PERSONAL_PHOTOS`
- **Music**: `src/lib/constants.ts` → `SONG_URL`
- **Text / names**: `src/lib/constants.ts` → `SITE`
- **Owner password**: change `rakhi2026` in `src/app/api/setup/route.ts` before deploying

---

Made with ❤️ — Happy Raksha Bandhan!
